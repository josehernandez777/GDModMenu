#!/usr/bin/env bash
# Adds the GD Mod Menu payload to YOUR OWN copy of Geometry Dash.
# Input can be a single .apk OR a bundle (.apks / .xapk / zip that contains several .apk files, e.g. a SAI backup).
# Usage: patch_gd_apk.sh <input> <payload_dir> <out.apk>
#   single APK  -> writes <out.apk>
#   bundle      -> writes <out>.apks (same name, .apks extension); install it with SAI
#   payload_dir has arm64-v8a/libgdmenu_payload.so and/or armeabi-v7a/libgdmenu_payload.so
# Needs: patchelf zip unzip keytool + Android build-tools (zipalign, apksigner).
# Everything is re-signed with ONE new key, so uninstall the original game first (back up your data).
set -euo pipefail
IN="${1:?input}"; PAY="${2:?payload_dir}"; OUT="${3:?out.apk}"
WORK="$(mktemp -d)"; trap 'rm -rf "$WORK"' EXIT

find_tool() {
  command -v "$1" 2>/dev/null && return
  ls "${ANDROID_HOME:-${ANDROID_SDK_ROOT:-/nonexistent}}"/build-tools/*/"$1" 2>/dev/null | sort -V | tail -n 1
}
ZIPALIGN="$(find_tool zipalign)"; APKSIGNER="$(find_tool apksigner)"
[ -n "$ZIPALIGN" ] && [ -n "$APKSIGNER" ] || { echo "ERROR: zipalign/apksigner not found (install Android build-tools)"; exit 1; }
command -v patchelf >/dev/null || { echo "ERROR: patchelf not installed"; exit 1; }

keytool -genkeypair -keystore "$WORK/ks.jks" -alias gd -keyalg RSA -keysize 2048 -validity 10000 \
  -storepass android -keypass android -dname "CN=GDMenu" >/dev/null 2>&1

PATCHED=0

# patch_one <in.apk> <out.apk>: patches libcocos2dcpp.so if present, then re-zips, aligns and signs.
patch_one() {
  local in="$1" out="$2" d
  d="$(mktemp -d -p "$WORK")"
  unzip -q "$in" -d "$d"
  local abi lib
  for abi in arm64-v8a armeabi-v7a; do
    lib="$d/lib/$abi/libcocos2dcpp.so"
    [ -f "$lib" ] || continue
    if [ ! -f "$PAY/$abi/libgdmenu_payload.so" ]; then echo "  skip $abi: no payload built"; continue; fi
    patchelf --add-needed libgdmenu_payload.so "$lib"
    cp "$PAY/$abi/libgdmenu_payload.so" "$d/lib/$abi/"
    echo "  patched $abi in $(basename "$in")"
    PATCHED=1
  done
  rm -rf "$d/META-INF"
  local unsigned="$d.unsigned.apk" aligned="$d.aligned.apk"
  rm -f "$unsigned"
  ( cd "$d"
    zip -q -X -r "$unsigned" . -x 'lib/*' 'resources.arsc'
    items=()
    [ -d lib ] && items+=(lib)
    [ -f resources.arsc ] && items+=(resources.arsc)
    if [ "${#items[@]}" -gt 0 ]; then zip -q -X -0 -r "$unsigned" "${items[@]}"; fi )
  "$ZIPALIGN" -p -f 4 "$unsigned" "$aligned"
  "$APKSIGNER" sign --ks "$WORK/ks.jks" --ks-pass pass:android --key-pass pass:android --out "$out" "$aligned"
}

if unzip -Z1 "$IN" | grep -qE '^[^/]+\.apk$'; then
  echo "Bundle detected (several .apk files inside)"
  mkdir "$WORK/bundle" "$WORK/out"
  unzip -q "$IN" -d "$WORK/bundle"
  for apk in "$WORK"/bundle/*.apk; do
    echo "- $(basename "$apk")"
    patch_one "$apk" "$WORK/out/$(basename "$apk")"
  done
  find "$WORK/bundle" -mindepth 1 -maxdepth 1 ! -name '*.apk' -exec cp -r {} "$WORK/out/" \;
  [ "$PATCHED" = 1 ] || { echo "ERROR: no libcocos2dcpp.so found in any APK of the bundle."; exit 1; }
  OUTB="$(realpath -m "${OUT%.*}.apks")"
  ( cd "$WORK/out" && zip -q -X -0 -r "$OUTB" . )
  echo "OK -> $OUTB (install with SAI)"
else
  echo "Single APK detected"
  patch_one "$IN" "$OUT"
  [ "$PATCHED" = 1 ] || { echo "ERROR: no libcocos2dcpp.so found in the APK. Export ALL parts of the game (SAI backup as .apks)."; exit 1; }
  echo "OK -> $OUT"
fi
