#!/usr/bin/env bash
# Adds the GD Mod Menu payload to YOUR OWN copy of the Geometry Dash APK.
# Usage: patch_gd_apk.sh <gd.apk> <payload_dir> <out.apk>
#   payload_dir has arm64-v8a/libgdmenu_payload.so and/or armeabi-v7a/libgdmenu_payload.so
# Needs: patchelf zip unzip keytool + Android build-tools (zipalign, apksigner).
# The result is signed with a new key: uninstall the original game first (back up your data).
set -euo pipefail
IN="${1:?gd.apk}"; PAY="${2:?payload_dir}"; OUT="${3:?out.apk}"
WORK="$(mktemp -d)"; trap 'rm -rf "$WORK"' EXIT

find_tool() {
  command -v "$1" 2>/dev/null && return
  ls "${ANDROID_HOME:-${ANDROID_SDK_ROOT:-/nonexistent}}"/build-tools/*/"$1" 2>/dev/null | sort -V | tail -n 1
}
ZIPALIGN="$(find_tool zipalign)"; APKSIGNER="$(find_tool apksigner)"
[ -n "$ZIPALIGN" ] && [ -n "$APKSIGNER" ] || { echo "ERROR: zipalign/apksigner not found (install Android build-tools)"; exit 1; }
command -v patchelf >/dev/null || { echo "ERROR: patchelf not installed"; exit 1; }

mkdir "$WORK/apk"
unzip -q "$IN" -d "$WORK/apk"

patched=0
for abi in arm64-v8a armeabi-v7a; do
  lib="$WORK/apk/lib/$abi/libcocos2dcpp.so"
  [ -f "$lib" ] || continue
  if [ ! -f "$PAY/$abi/libgdmenu_payload.so" ]; then echo "skip $abi: no payload built"; continue; fi
  patchelf --add-needed libgdmenu_payload.so "$lib"
  cp "$PAY/$abi/libgdmenu_payload.so" "$WORK/apk/lib/$abi/"
  echo "patched $abi"
  patched=1
done
[ "$patched" = 1 ] || { echo "ERROR: no libcocos2dcpp.so found in the APK. Use the full single APK (not xapk/split)."; exit 1; }

rm -rf "$WORK/apk/META-INF"
( cd "$WORK/apk"
  zip -q -X -r "$WORK/unsigned.apk" . -x 'lib/*' 'resources.arsc'
  zip -q -X -0 -r "$WORK/unsigned.apk" lib resources.arsc )
"$ZIPALIGN" -p -f 4 "$WORK/unsigned.apk" "$WORK/aligned.apk"
keytool -genkeypair -keystore "$WORK/ks.jks" -alias gd -keyalg RSA -keysize 2048 -validity 10000 \
  -storepass android -keypass android -dname "CN=GDMenu" >/dev/null 2>&1
"$APKSIGNER" sign --ks "$WORK/ks.jks" --ks-pass pass:android --key-pass pass:android --out "$OUT" "$WORK/aligned.apk"
echo "OK -> $OUT"
