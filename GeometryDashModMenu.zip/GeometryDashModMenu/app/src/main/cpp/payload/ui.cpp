// In-game menu. Compiled with ImGui when CMake could fetch it (GDMM_HAS_IMGUI), otherwise a stub.
#include "payload/ui.h"

#ifdef GDMM_HAS_IMGUI

#include <GLES2/gl2.h>
#include <dlfcn.h>
#include <jni.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

#include "backends/imgui_impl_opengl3.h"
#include "imgui.h"
#include "payload/game.h"
#include "payload/hook.h"

#ifdef GDMM_HAS_FONT
static const unsigned char kFontData[] = {
#include "gdmm_font.inc"
};
#endif

namespace gdmm::ui {
namespace {

using Clock = std::chrono::steady_clock;

constexpr uint32_t kSurviveFrames = 300;
constexpr int kInjectId = 7;  // touch id used for replayed touches (real fingers use other ids)

struct Rect {
    float x, y, w, h;
};
struct TouchEv {
    int64_t tMs;
    bool down;
    float x, y;  // normalized 0..1 of the screen
};
enum TouchState { T_IDLE, T_ARMED, T_RECORDING, T_COUNTDOWN, T_PLAYING };

// ---- state (all touched only from the game's GL thread, except the atomics) ----
bool g_inited = false;
bool g_showMenu = false;
bool g_capturing = false;
std::atomic<bool> g_installed{false};
std::atomic<bool> g_hidden{false};
Rect g_rects[4];
int g_rectCount = 0;
std::string g_message = "ready";
int g_tab = 0;
uint32_t g_frames = 0;
float g_scale = 2.0f;
float g_dispW = 0.0f, g_dispH = 0.0f;
void (*g_onSurvived)() = nullptr;
Clock::time_point g_last;

// touch macro
TouchState g_tState = T_IDLE;
std::vector<TouchEv> g_tRec, g_tPlay;
Clock::time_point g_tStart;
size_t g_tIdx = 0;
bool g_tHeld = false;
float g_tLastX = 0.0f, g_tLastY = 0.0f;
float g_tDelaySec = 3.0f;
void* g_env = nullptr;

using DrawFn = void (*)(void*);
using InvalidateFn = void (*)();
using TouchFn = void (*)(void*, void*, int, float, float);
using MoveFn = void (*)(void*, void*, void*, void*, void*);

DrawFn o_draw = nullptr;
InvalidateFn g_invalidate = nullptr;
TouchFn o_begin = nullptr;
TouchFn o_end = nullptr;
TouchFn o_cancel = nullptr;
MoveFn o_move = nullptr;

float S(float v) { return v * g_scale; }

int64_t msSince(Clock::time_point t) {
    return std::chrono::duration_cast<std::chrono::milliseconds>(Clock::now() - t).count();
}

// ---------------------------------------------------------------- touch macro (real touches)

void injectTouch(bool down, float nx, float ny) {
    TouchFn fn = down ? o_begin : o_end;
    if (!fn || g_dispW <= 0.0f) return;
    g_tHeld = down;
    g_tLastX = nx * g_dispW;
    g_tLastY = ny * g_dispH;
    fn(g_env, nullptr, kInjectId, g_tLastX, g_tLastY);  // the cocos entry points ignore env/class
}

void releaseHeld() {
    if (g_tHeld && o_end) o_end(g_env, nullptr, kInjectId, g_tLastX, g_tLastY);
    g_tHeld = false;
}

void stopTouchMacro() {
    if (g_tState == T_RECORDING || g_tState == T_ARMED) g_tPlay = g_tRec;  // the recording becomes the loaded macro
    if (g_tState == T_PLAYING || g_tState == T_COUNTDOWN) releaseHeld();
    g_tState = T_IDLE;
}

void recordTouch(bool down, float x, float y) {
    if (g_tState == T_ARMED && down) {
        g_tState = T_RECORDING;
        g_tStart = Clock::now();
        g_tRec.clear();
    }
    if (g_tState != T_RECORDING || g_dispW <= 0.0f || g_dispH <= 0.0f) return;
    g_tRec.push_back({msSince(g_tStart), down, std::min(1.0f, std::max(0.0f, x / g_dispW)),
                      std::min(1.0f, std::max(0.0f, y / g_dispH))});
}

void touchMacroTick() {
    if (g_tState == T_COUNTDOWN) {
        if (Clock::now() < g_tStart) return;
        g_tState = T_PLAYING;
        g_tIdx = 0;
    }
    if (g_tState != T_PLAYING) return;
    const int64_t t = msSince(g_tStart);
    while (g_tIdx < g_tPlay.size() && g_tPlay[g_tIdx].tMs <= t) {
        injectTouch(g_tPlay[g_tIdx].down, g_tPlay[g_tIdx].x, g_tPlay[g_tIdx].y);
        g_tIdx++;
    }
    if (g_tIdx >= g_tPlay.size()) {
        releaseHeld();
        g_tState = T_IDLE;
    }
}

std::string touchSlotPath(int slot) { return game::dataDir() + "/touch_" + std::to_string(slot) + ".txt"; }

std::string saveTouchSlot(int slot) {
    const std::vector<TouchEv>& ev = g_tRec.empty() ? g_tPlay : g_tRec;
    if (ev.empty()) return "nothing to save";
    FILE* f = fopen(touchSlotPath(slot).c_str(), "w");
    if (!f) return "cannot write " + touchSlotPath(slot);
    fprintf(f, "GDMM-TOUCH 1\n");
    for (const TouchEv& e : ev) {
        fprintf(f, "%lld,%c,%.5f,%.5f\n", static_cast<long long>(e.tMs), e.down ? 'D' : 'U', e.x, e.y);
    }
    fclose(f);
    return "saved " + std::to_string(ev.size()) + " touches to slot " + std::to_string(slot);
}

std::string loadTouchSlot(int slot) {
    FILE* f = fopen(touchSlotPath(slot).c_str(), "r");
    if (!f) return "slot " + std::to_string(slot) + " is empty";
    char line[128];
    std::vector<TouchEv> ev;
    bool header = false, ok = true;
    int64_t last = 0;
    while (fgets(line, sizeof(line), f)) {
        if (!header) {
            header = strncmp(line, "GDMM-TOUCH 1", 12) == 0;
            if (!header) {
                ok = false;
                break;
            }
            continue;
        }
        long long t = 0;
        char type = 0;
        float x = 0, y = 0;
        if (sscanf(line, "%lld,%c,%f,%f", &t, &type, &x, &y) != 4 || (type != 'D' && type != 'U') || t < last ||
            x < 0 || x > 1 || y < 0 || y > 1) {
            ok = false;
            break;
        }
        last = t;
        ev.push_back({static_cast<int64_t>(t), type == 'D', x, y});
    }
    fclose(f);
    if (!ok || !header) return "slot file is not a valid touch macro";
    g_tPlay = ev;
    return "loaded " + std::to_string(ev.size()) + " touches from slot " + std::to_string(slot);
}

// ---------------------------------------------------------------- look and feel

const ImVec4 kAccent(0.545f, 0.361f, 0.965f, 1.0f);       // #8B5CF6
const ImVec4 kAccentDim(0.215f, 0.150f, 0.420f, 1.0f);
const ImVec4 kMuted(0.56f, 0.54f, 0.66f, 1.0f);
const ImVec4 kGood(0.29f, 0.87f, 0.50f, 1.0f);
const ImVec4 kWarn(0.96f, 0.73f, 0.29f, 1.0f);

void applyTheme() {
    ImGuiStyle& st = ImGui::GetStyle();
    st.WindowRounding = S(14);
    st.ChildRounding = S(12);
    st.FrameRounding = S(10);
    st.GrabRounding = S(10);
    st.PopupRounding = S(10);
    st.ScrollbarRounding = S(10);
    st.WindowPadding = ImVec2(S(14), S(12));
    st.FramePadding = ImVec2(S(12), S(8));
    st.ItemSpacing = ImVec2(S(10), S(10));
    st.ScrollbarSize = S(16);
    st.GrabMinSize = S(26);
    st.WindowBorderSize = 1.0f;
    st.FrameBorderSize = 0.0f;
    st.WindowTitleAlign = ImVec2(0.5f, 0.5f);

    ImVec4* c = st.Colors;
    c[ImGuiCol_Text] = ImVec4(0.93f, 0.92f, 0.97f, 1.0f);
    c[ImGuiCol_TextDisabled] = kMuted;
    c[ImGuiCol_WindowBg] = ImVec4(0.055f, 0.047f, 0.086f, 0.97f);
    c[ImGuiCol_ChildBg] = ImVec4(0.078f, 0.070f, 0.122f, 1.0f);
    c[ImGuiCol_PopupBg] = ImVec4(0.078f, 0.070f, 0.122f, 0.98f);
    c[ImGuiCol_Border] = ImVec4(0.17f, 0.15f, 0.27f, 1.0f);
    c[ImGuiCol_FrameBg] = ImVec4(0.12f, 0.10f, 0.20f, 1.0f);
    c[ImGuiCol_FrameBgHovered] = ImVec4(0.17f, 0.14f, 0.28f, 1.0f);
    c[ImGuiCol_FrameBgActive] = ImVec4(0.21f, 0.17f, 0.34f, 1.0f);
    c[ImGuiCol_TitleBg] = ImVec4(0.09f, 0.075f, 0.15f, 1.0f);
    c[ImGuiCol_TitleBgActive] = ImVec4(0.14f, 0.10f, 0.28f, 1.0f);
    c[ImGuiCol_TitleBgCollapsed] = ImVec4(0.09f, 0.075f, 0.15f, 1.0f);
    c[ImGuiCol_ScrollbarBg] = ImVec4(0.0f, 0.0f, 0.0f, 0.0f);
    c[ImGuiCol_ScrollbarGrab] = ImVec4(0.30f, 0.22f, 0.55f, 1.0f);
    c[ImGuiCol_ScrollbarGrabHovered] = ImVec4(0.40f, 0.30f, 0.70f, 1.0f);
    c[ImGuiCol_ScrollbarGrabActive] = kAccent;
    c[ImGuiCol_CheckMark] = kAccent;
    c[ImGuiCol_SliderGrab] = kAccent;
    c[ImGuiCol_SliderGrabActive] = ImVec4(0.68f, 0.52f, 1.0f, 1.0f);
    c[ImGuiCol_Button] = ImVec4(0.30f, 0.20f, 0.62f, 1.0f);
    c[ImGuiCol_ButtonHovered] = ImVec4(0.40f, 0.28f, 0.78f, 1.0f);
    c[ImGuiCol_ButtonActive] = kAccent;
    c[ImGuiCol_Header] = kAccentDim;
    c[ImGuiCol_HeaderHovered] = ImVec4(0.30f, 0.21f, 0.56f, 1.0f);
    c[ImGuiCol_HeaderActive] = kAccent;
    c[ImGuiCol_Separator] = ImVec4(0.17f, 0.15f, 0.27f, 1.0f);
    c[ImGuiCol_ResizeGrip] = kAccentDim;
    c[ImGuiCol_ResizeGripHovered] = ImVec4(0.40f, 0.30f, 0.70f, 1.0f);
    c[ImGuiCol_ResizeGripActive] = kAccent;
}

void trackWindow() {
    const ImVec2 p = ImGui::GetWindowPos();
    const ImVec2 s = ImGui::GetWindowSize();
    if (g_rectCount < 4) g_rects[g_rectCount++] = {p.x, p.y, s.x, s.y};
}

bool insideMenu(float x, float y) {
    for (int i = 0; i < g_rectCount; i++) {
        const Rect& r = g_rects[i];
        if (x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h) return true;
    }
    return false;
}

// iOS-style switch with a label on its right.
bool toggleRow(const char* label, bool* value) {
    ImGui::PushID(label);
    const float h = ImGui::GetFrameHeight();
    const float w = h * 1.9f;
    const ImVec2 p = ImGui::GetCursorScreenPos();
    ImGui::InvisibleButton("##toggle", ImVec2(w, h));
    bool changed = false;
    if (ImGui::IsItemClicked()) {
        *value = !*value;
        changed = true;
    }
    ImDrawList* dl = ImGui::GetWindowDrawList();
    const ImU32 track = *value ? ImGui::GetColorU32(kAccent) : ImGui::GetColorU32(ImVec4(0.20f, 0.17f, 0.30f, 1.0f));
    dl->AddRectFilled(p, ImVec2(p.x + w, p.y + h), track, h * 0.5f);
    const float knobX = *value ? p.x + w - h * 0.5f : p.x + h * 0.5f;
    dl->AddCircleFilled(ImVec2(knobX, p.y + h * 0.5f), h * 0.5f - S(4), IM_COL32(255, 255, 255, 255));
    ImGui::SameLine();
    ImGui::AlignTextToFramePadding();
    ImGui::TextUnformatted(label);
    ImGui::PopID();
    return changed;
}

void sectionTitle(const char* text) {
    ImGui::Spacing();
    ImGui::TextColored(kAccent, "%s", text);
    ImGui::Separator();
}

bool navButton(const char* label, bool selected) {
    ImGui::PushStyleColor(ImGuiCol_Button, selected ? kAccent : ImVec4(0.0f, 0.0f, 0.0f, 0.0f));
    ImGui::PushStyleColor(ImGuiCol_Text, selected ? ImVec4(1.0f, 1.0f, 1.0f, 1.0f) : kMuted);
    const bool pressed = ImGui::Button(label, ImVec2(ImGui::GetContentRegionAvail().x, S(44)));
    ImGui::PopStyleColor(2);
    return pressed;
}

void unavailable(const char* what, const char* why) {
    ImGui::TextColored(kWarn, "%s unavailable", what);
    ImGui::TextWrapped("%s", why);
}

const char* touchStateText() {
    switch (g_tState) {
        case T_ARMED: return "ARMED: your first touch on the game starts recording";
        case T_RECORDING: return "RECORDING";
        case T_COUNTDOWN: return "STARTING...";
        case T_PLAYING: return "PLAYING";
        default: return "idle";
    }
}

void tabPlayer() {
    sectionTitle("PLAYER");
    if (game::canNoclip()) {
        bool v = game::noclip();
        if (toggleRow("Noclip", &v)) game::setNoclip(v);
        ImGui::TextColored(kMuted, "The player is not destroyed by obstacles.");
    } else {
        unavailable("Noclip", "The game function PlayLayer::destroyPlayer was not found in this version (see ABOUT).");
    }
}

void tabGameplay() {
    sectionTitle("SPEED");
    if (game::canSpeed()) {
        float s = game::speed();
        ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x);
        if (ImGui::SliderFloat("##speed", &s, 0.1f, 4.0f, "%.2fx")) game::setSpeed(s);
        if (ImGui::Button("0.5x")) game::setSpeed(0.5f);
        ImGui::SameLine();
        if (ImGui::Button("1x")) game::setSpeed(1.0f);
        ImGui::SameLine();
        if (ImGui::Button("2x")) game::setSpeed(2.0f);
        ImGui::SameLine();
        if (ImGui::Button("3x")) game::setSpeed(3.0f);

        sectionTitle("FRAME CONTROL");
        bool f = game::frozen();
        if (toggleRow("Freeze", &f)) game::setFreeze(f);
        if (game::frozen()) {
            if (ImGui::Button("Step 1 frame", ImVec2(ImGui::GetContentRegionAvail().x, S(44)))) game::step();
        }
    } else {
        unavailable("Speed and freeze", "cocos2d::CCScheduler::update was not found.");
    }
}

void tabVisual() {
    sectionTitle("EFFECTS");
    if (game::canShake()) {
        bool v = game::noShake();
        if (toggleRow("No shake", &v)) game::setNoShake(v);
    } else {
        unavailable("No shake", "GJBaseGameLayer::shakeCamera was not found.");
    }
    if (game::canDeathFx()) {
        bool v = game::noDeathFx();
        if (toggleRow("No death effect", &v)) game::setNoDeathFx(v);
    } else {
        unavailable("No death effect", "PlayerObject::playDeathEffect was not found.");
    }
    sectionTitle("INFO");
    ImGui::Text("FPS: %.1f", game::fps());
}

void tabMacros() {
    sectionTitle("TOUCH MACRO");
    ImGui::TextColored(kMuted, "Records and replays your real touches inside the game.");
    ImGui::Text("State: %s", touchStateText());
    ImGui::Text("Recorded %zu | loaded %zu", g_tRec.size(), g_tPlay.size());
    if (!o_begin || !o_end) {
        unavailable("Touch macro", "The cocos touch entry points are not hooked.");
    } else {
        if (ImGui::Button("Record")) {
            if (g_tState == T_IDLE) {
                g_tRec.clear();
                g_tState = T_ARMED;
                g_message = "Armed. Close this menu and touch the game: recording starts at your first touch.";
            }
        }
        ImGui::SameLine();
        if (ImGui::Button("Stop")) {
            stopTouchMacro();
            g_message = "Stopped. " + std::to_string(g_tPlay.size()) + " touches loaded.";
        }
        ImGui::SameLine();
        if (ImGui::Button("Play")) {
            if (g_tPlay.empty()) {
                g_message = "Nothing to play: record or load a macro first.";
            } else if (g_tState == T_IDLE) {
                g_tState = T_COUNTDOWN;
                g_tStart = Clock::now() + std::chrono::milliseconds(static_cast<int>(g_tDelaySec * 1000.0f));
                g_message = "Starting soon: close this menu. Time zero is your first recorded touch.";
            }
        }
        ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x * 0.6f);
        ImGui::SliderFloat("Start delay", &g_tDelaySec, 0.0f, 10.0f, "%.1f s");
        for (int slot = 1; slot <= 3; slot++) {
            ImGui::PushID(100 + slot);
            ImGui::Text("Slot %d", slot);
            ImGui::SameLine();
            if (ImGui::Button("Save")) g_message = saveTouchSlot(slot);
            ImGui::SameLine();
            if (ImGui::Button("Load")) g_message = loadTouchSlot(slot);
            ImGui::PopID();
        }
    }

    if (game::canMacro()) {
        sectionTitle("FRAME MACRO (exact)");
        ImGui::Text("State: %s | recorded %zu | loaded %zu", game::macroState().c_str(), game::macroRecordedCount(),
                    game::macroLoadedCount());
        if (ImGui::Button("Record##f")) g_message = game::macroRecord();
        ImGui::SameLine();
        if (ImGui::Button("Stop##f")) g_message = game::macroStop();
        ImGui::SameLine();
        if (ImGui::Button("Play##f")) g_message = game::macroPlay();
        for (int slot = 1; slot <= 3; slot++) {
            ImGui::PushID(slot);
            ImGui::Text("Slot %d", slot);
            ImGui::SameLine();
            if (ImGui::Button("Save")) g_message = game::macroSave(slot);
            ImGui::SameLine();
            if (ImGui::Button("Load")) g_message = game::macroLoad(slot);
            ImGui::PopID();
        }
    }
    ImGui::Separator();
    ImGui::TextWrapped("%s", g_message.c_str());
}

void tabAbout() {
    sectionTitle("GD MOD MENU");
    ImGui::TextColored(kMuted, "Independent mod menu: no Geode, no Mega Hack, no root.");
    sectionTitle("HOOKS");
    ImGui::TextWrapped("%s", game::status().c_str());
    sectionTitle("INSTALL REPORT");
    const std::string report = game::lastReport();
    ImGui::TextWrapped("%s", report.empty() ? "(no report yet)" : report.c_str());
}

void buildUi() {
    ImGuiIO& io = ImGui::GetIO();

    // Always-visible pill to open/close the menu.
    ImGui::SetNextWindowPos(ImVec2(S(10), S(10)), ImGuiCond_Always);
    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.0f, 0.0f, 0.0f, 0.0f));
    ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0.0f, 0.0f, 0.0f, 0.0f));
    ImGui::Begin("##gdmm_toggle", nullptr,
                 ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoMove |
                     ImGuiWindowFlags_NoSavedSettings);
    if (ImGui::Button(g_showMenu ? "GD  -" : "GD  +")) g_showMenu = !g_showMenu;
    trackWindow();
    ImGui::End();
    ImGui::PopStyleColor(2);
    if (!g_showMenu) return;

    ImGui::SetNextWindowPos(ImVec2(io.DisplaySize.x * 0.07f, io.DisplaySize.y * 0.12f), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize(ImVec2(io.DisplaySize.x * 0.6f, io.DisplaySize.y * 0.78f), ImGuiCond_FirstUseEver);
    if (ImGui::Begin("GD MOD MENU", &g_showMenu, ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoCollapse)) {
        ImGui::BeginChild("nav", ImVec2(S(140), 0), 0);
        const char* tabs[] = {"PLAYER", "GAMEPLAY", "VISUAL", "MACROS", "ABOUT"};
        for (int i = 0; i < 5; i++) {
            if (navButton(tabs[i], g_tab == i)) g_tab = i;
        }
        ImGui::EndChild();
        ImGui::SameLine();
        ImGui::BeginChild("content", ImVec2(0, 0), 0);
        switch (g_tab) {
            case 0: tabPlayer(); break;
            case 1: tabGameplay(); break;
            case 2: tabVisual(); break;
            case 3: tabMacros(); break;
            default: tabAbout(); break;
        }
        ImGui::EndChild();
    }
    trackWindow();
    ImGui::End();
}

// ---------------------------------------------------------------- rendering

void renderMenu() {
    if (!g_inited) {
        g_scale = std::max(1.0f, g_dispH / 720.0f);
        IMGUI_CHECKVERSION();
        ImGui::CreateContext();
        ImGuiIO& io = ImGui::GetIO();
        io.IniFilename = nullptr;
#ifdef GDMM_HAS_FONT
        ImFontConfig cfg;
        cfg.FontDataOwnedByAtlas = false;
        io.Fonts->AddFontFromMemoryTTF(const_cast<unsigned char*>(kFontData), static_cast<int>(sizeof(kFontData)),
                                       S(17), &cfg);
#else
        io.FontGlobalScale = g_scale * 1.4f;
#endif
        ImGui::StyleColorsDark();
        applyTheme();
        if (!ImGui_ImplOpenGL3_Init("#version 100")) {
            gdmm::logMessage("ui: ImGui_ImplOpenGL3_Init failed");
            return;
        }
        g_last = Clock::now();
        g_inited = true;
    }

    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize = ImVec2(g_dispW, g_dispH);
    const auto now = Clock::now();
    io.DeltaTime = std::max(1.0f / 1000.0f, std::chrono::duration<float>(now - g_last).count());
    g_last = now;

    // The game caches GL state. ImGui's backend restores program, textures, buffers, blend and scissor,
    // but NOT which vertex attribute arrays are enabled: save and restore them exactly.
    GLint maxAttribs = 8;
    glGetIntegerv(GL_MAX_VERTEX_ATTRIBS, &maxAttribs);
    maxAttribs = std::min<GLint>(16, std::max<GLint>(8, maxAttribs));
    GLint enabled[16] = {0};
    for (GLint i = 0; i < maxAttribs; i++) glGetVertexAttribiv(static_cast<GLuint>(i), GL_VERTEX_ATTRIB_ARRAY_ENABLED, &enabled[i]);

    ImGui_ImplOpenGL3_NewFrame();
    ImGui::NewFrame();
    g_rectCount = 0;
    buildUi();
    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

    for (GLint i = 0; i < maxAttribs; i++) {
        if (enabled[i]) {
            glEnableVertexAttribArray(static_cast<GLuint>(i));
        } else {
            glDisableVertexAttribArray(static_cast<GLuint>(i));
        }
    }
    if (g_invalidate) g_invalidate();

    if (++g_frames == kSurviveFrames && g_onSurvived) g_onSurvived();
}

void hkDrawScene(void* self) {
    if (o_draw) o_draw(self);

    GLint vp[4] = {0, 0, 0, 0};
    glGetIntegerv(GL_VIEWPORT, vp);
    if (vp[2] <= 0 || vp[3] <= 0) return;
    g_dispW = static_cast<float>(vp[2]);
    g_dispH = static_cast<float>(vp[3]);

    touchMacroTick();
    if (!g_hidden.load()) renderMenu();
}

// ---- touch input: the menu gets touches that start inside its windows; the game never sees them ----

void hkTouchBegin(void* env, void* cls, int id, float x, float y) {
    if (env) g_env = env;
    if (g_inited && !g_hidden.load()) {
        ImGuiIO& io = ImGui::GetIO();
        io.AddMousePosEvent(x, y);
        if (insideMenu(x, y)) {
            g_capturing = true;
            io.AddMouseButtonEvent(0, true);
            return;
        }
    }
    recordTouch(true, x, y);
    if (o_begin) o_begin(env, cls, id, x, y);
}

void hkTouchEnd(void* env, void* cls, int id, float x, float y) {
    if (env) g_env = env;
    if (g_inited) {
        ImGuiIO& io = ImGui::GetIO();
        io.AddMousePosEvent(x, y);
        if (g_capturing) {
            g_capturing = false;
            io.AddMouseButtonEvent(0, false);
            return;
        }
    }
    recordTouch(false, x, y);
    if (o_end) o_end(env, cls, id, x, y);
}

void hkTouchCancel(void* env, void* cls, int id, float x, float y) {
    if (g_inited) {
        ImGuiIO& io = ImGui::GetIO();
        io.AddMousePosEvent(x, y);
        if (g_capturing) {
            g_capturing = false;
            io.AddMouseButtonEvent(0, false);
            return;
        }
    }
    recordTouch(false, x, y);
    if (o_cancel) o_cancel(env, cls, id, x, y);
}

void hkTouchMove(void* env, void* cls, void* ids, void* xs, void* ys) {
    if (g_inited && env && xs && ys) {
        JNIEnv* e = static_cast<JNIEnv*>(env);
        jfloatArray fx = static_cast<jfloatArray>(xs);
        jfloatArray fy = static_cast<jfloatArray>(ys);
        if (e->GetArrayLength(fx) > 0 && e->GetArrayLength(fy) > 0) {
            float x = 0.0f, y = 0.0f;
            e->GetFloatArrayRegion(fx, 0, 1, &x);
            e->GetFloatArrayRegion(fy, 0, 1, &y);
            ImGui::GetIO().AddMousePosEvent(x, y);
        }
        if (g_capturing) return;
    }
    if (o_move) o_move(env, cls, ids, xs, ys);
}

}  // namespace

bool installed() { return g_installed.load(); }

void setHidden(bool hidden) { g_hidden.store(hidden); }

std::string installHooks(void* handle, void (*onSurvived)()) {
    if (g_installed.load()) return "UI already installed\n";
    if (!handle) return "UI: game library not ready\n";

    struct Item {
        const char* label;
        const char* symbol;
        void* replacement;
        void** original;
        void* address;
    };
    Item items[] = {
        {"CCDirector::drawScene()", "_ZN7cocos2d10CCDirector9drawSceneEv", reinterpret_cast<void*>(&hkDrawScene),
         reinterpret_cast<void**>(&o_draw), nullptr},
        {"nativeTouchesBegin", "Java_org_cocos2dx_lib_Cocos2dxRenderer_nativeTouchesBegin",
         reinterpret_cast<void*>(&hkTouchBegin), reinterpret_cast<void**>(&o_begin), nullptr},
        {"nativeTouchesMove", "Java_org_cocos2dx_lib_Cocos2dxRenderer_nativeTouchesMove",
         reinterpret_cast<void*>(&hkTouchMove), reinterpret_cast<void**>(&o_move), nullptr},
        {"nativeTouchesEnd", "Java_org_cocos2dx_lib_Cocos2dxRenderer_nativeTouchesEnd",
         reinterpret_cast<void*>(&hkTouchEnd), reinterpret_cast<void**>(&o_end), nullptr},
        {"nativeTouchesCancel", "Java_org_cocos2dx_lib_Cocos2dxRenderer_nativeTouchesCancel",
         reinterpret_cast<void*>(&hkTouchCancel), reinterpret_cast<void**>(&o_cancel), nullptr},
    };

    std::string report;
    bool missing = false;
    for (Item& it : items) {
        it.address = dlsym(handle, it.symbol);
        if (!it.address) {
            missing = true;
            report += std::string("UI MISSING  ") + it.label + "  (" + it.symbol + " is not exported)\n";
            report += game::similarExports(it.label[0] == 'n' ? "nativeTouches" : "drawScene", "");
        }
    }
    if (missing) {
        report += "UI not installed: it needs every symbol above (a menu you cannot tap is useless).\n";
        return report;
    }

    // cocos2d-x 2.x declares its GL state helpers inside namespace cocos2d.
    g_invalidate = reinterpret_cast<InvalidateFn>(dlsym(handle, "_ZN7cocos2d24ccGLInvalidateStateCacheEv"));
    if (!g_invalidate) g_invalidate = reinterpret_cast<InvalidateFn>(dlsym(handle, "_Z24ccGLInvalidateStateCachev"));
    g_onSurvived = onSurvived;

    // Touch hooks first, drawing last: the menu only appears once it can be tapped.
    for (size_t i = 1; i < sizeof(items) / sizeof(items[0]); i++) {
        std::string err;
        if (!installHook(items[i].address, items[i].replacement, items[i].original, err)) {
            report += std::string("UI FAILED   ") + items[i].label + ": " + err + "\n";
            report += "UI not installed (hooks already placed stay inert: the menu is never drawn).\n";
            return report;
        }
        report += std::string("UI HOOKED   ") + items[i].label + "\n";
    }
    std::string err;
    if (!installHook(items[0].address, items[0].replacement, items[0].original, err)) {
        report += "UI FAILED   CCDirector::drawScene(): " + err + "\n";
        return report;
    }
    report += "UI HOOKED   CCDirector::drawScene()\n";
    report += g_invalidate ? "UI note: GL state cache invalidation available.\n"
                           : "UI note: ccGLInvalidateStateCache not exported (attribute state is restored manually).\n";
    g_installed.store(true);
    return report;
}

}  // namespace gdmm::ui

#else  // !GDMM_HAS_IMGUI

namespace gdmm::ui {

std::string installHooks(void*, void (*)()) {
    return "UI: ImGui was not available at build time (CMake could not fetch it); in-game menu not built.\n";
}

bool installed() { return false; }

void setHidden(bool) {}

}  // namespace gdmm::ui

#endif
