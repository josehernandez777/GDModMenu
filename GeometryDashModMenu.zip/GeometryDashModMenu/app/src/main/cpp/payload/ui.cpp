// In-game menu. Compiled with ImGui when CMake could fetch it (GDMM_HAS_IMGUI), otherwise a stub.
#include "payload/ui.h"

#ifdef GDMM_HAS_IMGUI

#include <GLES2/gl2.h>
#include <dlfcn.h>
#include <jni.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdio>
#include <string>

#include "backends/imgui_impl_opengl3.h"
#include "imgui.h"
#include "payload/game.h"
#include "payload/hook.h"

namespace gdmm::ui {
namespace {

constexpr float kScale = 3.0f;  // phone screens are dense; makes text and touch targets usable
constexpr uint32_t kSurviveFrames = 300;

struct Rect {
    float x, y, w, h;
};

bool g_inited = false;
bool g_showMenu = false;
bool g_capturing = false;
std::atomic<bool> g_installed{false};
Rect g_rects[4];
int g_rectCount = 0;
std::string g_message = "ready";
uint32_t g_frames = 0;
void (*g_onSurvived)() = nullptr;
std::chrono::steady_clock::time_point g_last;

using DrawFn = void (*)(void*);
using InvalidateFn = void (*)();
using TouchFn = void (*)(void*, void*, int, float, float);
using MoveFn = void (*)(void*, void*, void*, void*, void*);

DrawFn o_draw = nullptr;
InvalidateFn g_invalidate = nullptr;
TouchFn o_begin = nullptr;
TouchFn o_end = nullptr;
TouchFn o_cancel = nullptr;
MoveFn o_move = nullptr;

void trackWindow() {
    const ImVec2 p = ImGui::GetWindowPos();
    const ImVec2 s = ImGui::GetWindowSize();
    if (g_rectCount < 4) g_rects[g_rectCount++] = {p.x, p.y, s.x, s.y};
}

bool insideMenu(float x, float y) {
    for (int i = 0; i < g_rectCount; i++) {
        const Rect& r = g_rects[i];
        if (x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h) return true;
    }
    return false;
}

void buildUi() {
    ImGuiIO& io = ImGui::GetIO();

    // Always-visible round trip button to open/close the menu.
    ImGui::SetNextWindowPos(ImVec2(20.0f, 20.0f), ImGuiCond_Always);
    ImGui::Begin("##gdmm_toggle", nullptr,
                 ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoMove |
                     ImGuiWindowFlags_NoSavedSettings);
    if (ImGui::Button(g_showMenu ? "GD  -" : "GD  +")) g_showMenu = !g_showMenu;
    trackWindow();
    ImGui::End();
    if (!g_showMenu) return;

    ImGui::SetNextWindowPos(ImVec2(io.DisplaySize.x * 0.08f, io.DisplaySize.y * 0.12f), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize(ImVec2(io.DisplaySize.x * 0.5f, io.DisplaySize.y * 0.75f), ImGuiCond_FirstUseEver);
    if (ImGui::Begin("GD Mod Menu", &g_showMenu, ImGuiWindowFlags_NoSavedSettings)) {
        ImGui::Text("FPS: %.1f", game::fps());
        ImGui::Separator();

        if (game::canNoclip()) {
            bool v = game::noclip();
            if (ImGui::Checkbox("Noclip", &v)) game::setNoclip(v);
        }
        if (game::canSpeed()) {
            float s = game::speed();
            if (ImGui::SliderFloat("Speed", &s, 0.1f, 4.0f, "%.2fx")) game::setSpeed(s);
            bool f = game::frozen();
            if (ImGui::Checkbox("Freeze", &f)) game::setFreeze(f);
            if (game::frozen()) {
                ImGui::SameLine();
                if (ImGui::Button("Step 1 frame")) game::step();
            }
        }
        if (game::canShake()) {
            bool v = game::noShake();
            if (ImGui::Checkbox("No shake", &v)) game::setNoShake(v);
        }
        if (game::canDeathFx()) {
            bool v = game::noDeathFx();
            if (ImGui::Checkbox("No death effect", &v)) game::setNoDeathFx(v);
        }

        ImGui::Separator();
        if (game::canMacro()) {
            ImGui::Text("Macro: %s | recorded %zu | loaded %zu", game::macroState().c_str(),
                        game::macroRecordedCount(), game::macroLoadedCount());
            if (ImGui::Button("Record")) g_message = game::macroRecord();
            ImGui::SameLine();
            if (ImGui::Button("Stop")) g_message = game::macroStop();
            ImGui::SameLine();
            if (ImGui::Button("Play")) g_message = game::macroPlay();
            for (int slot = 1; slot <= 3; slot++) {
                ImGui::PushID(slot);
                ImGui::Text("Slot %d", slot);
                ImGui::SameLine();
                if (ImGui::Button("Save")) g_message = game::macroSave(slot);
                ImGui::SameLine();
                if (ImGui::Button("Load")) g_message = game::macroLoad(slot);
                ImGui::PopID();
            }
        } else {
            ImGui::TextWrapped("Macros unavailable: input hooks are missing (see GAME LINK > Status).");
        }
        ImGui::Separator();
        ImGui::TextWrapped("%s", g_message.c_str());
    }
    trackWindow();
    ImGui::End();
}

void renderMenu() {
    if (!g_inited) {
        IMGUI_CHECKVERSION();
        ImGui::CreateContext();
        ImGuiIO& io = ImGui::GetIO();
        io.IniFilename = nullptr;
        io.FontGlobalScale = kScale;
        ImGui::StyleColorsDark();
        ImGui::GetStyle().ScaleAllSizes(kScale);
        if (!ImGui_ImplOpenGL3_Init("#version 100")) {
            gdmm::logMessage("ui: ImGui_ImplOpenGL3_Init failed");
            return;
        }
        g_last = std::chrono::steady_clock::now();
        g_inited = true;
    }

    GLint vp[4] = {0, 0, 0, 0};
    glGetIntegerv(GL_VIEWPORT, vp);
    if (vp[2] <= 0 || vp[3] <= 0) return;

    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize = ImVec2(static_cast<float>(vp[2]), static_cast<float>(vp[3]));
    const auto now = std::chrono::steady_clock::now();
    io.DeltaTime = std::max(1.0f / 1000.0f, std::chrono::duration<float>(now - g_last).count());
    g_last = now;

    ImGui_ImplOpenGL3_NewFrame();
    ImGui::NewFrame();
    g_rectCount = 0;
    buildUi();
    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

    // cocos2d caches GL state: leave a clean slate so the next game frame draws correctly.
    for (GLuint i = 0; i < 8; i++) glDisableVertexAttribArray(i);
    if (g_invalidate) g_invalidate();

    if (++g_frames == kSurviveFrames && g_onSurvived) g_onSurvived();
}

void hkDrawScene(void* self) {
    if (o_draw) o_draw(self);
    renderMenu();
}

// ---- touch input: the menu gets touches that start inside its windows; the game never sees them ----

void hkTouchBegin(void* env, void* cls, int id, float x, float y) {
    if (g_inited) {
        ImGuiIO& io = ImGui::GetIO();
        io.AddMousePosEvent(x, y);
        if (insideMenu(x, y)) {
            g_capturing = true;
            io.AddMouseButtonEvent(0, true);
            return;
        }
    }
    if (o_begin) o_begin(env, cls, id, x, y);
}

void hkTouchEnd(void* env, void* cls, int id, float x, float y) {
    if (g_inited) {
        ImGuiIO& io = ImGui::GetIO();
        io.AddMousePosEvent(x, y);
        if (g_capturing) {
            g_capturing = false;
            io.AddMouseButtonEvent(0, false);
            return;
        }
    }
    if (o_end) o_end(env, cls, id, x, y);
}

void hkTouchCancel(void* env, void* cls, int id, float x, float y) {
    if (g_inited) {
        ImGuiIO& io = ImGui::GetIO();
        io.AddMousePosEvent(x, y);
        if (g_capturing) {
            g_capturing = false;
            io.AddMouseButtonEvent(0, false);
            return;
        }
    }
    if (o_cancel) o_cancel(env, cls, id, x, y);
}

void hkTouchMove(void* env, void* cls, void* ids, void* xs, void* ys) {
    if (g_inited && env && xs && ys) {
        JNIEnv* e = static_cast<JNIEnv*>(env);
        jfloatArray fx = static_cast<jfloatArray>(xs);
        jfloatArray fy = static_cast<jfloatArray>(ys);
        if (e->GetArrayLength(fx) > 0 && e->GetArrayLength(fy) > 0) {
            float x = 0.0f, y = 0.0f;
            e->GetFloatArrayRegion(fx, 0, 1, &x);
            e->GetFloatArrayRegion(fy, 0, 1, &y);
            ImGui::GetIO().AddMousePosEvent(x, y);
        }
        if (g_capturing) return;
    }
    if (o_move) o_move(env, cls, ids, xs, ys);
}

}  // namespace

bool installed() { return g_installed.load(); }

std::string installHooks(void* handle, void (*onSurvived)()) {
    if (g_installed.load()) return "UI already installed\n";
    if (!handle) return "UI: game library not ready\n";

    struct Item {
        const char* label;
        const char* symbol;
        void* replacement;
        void** original;
        void* address;
    };
    Item items[] = {
        {"CCDirector::drawScene()", "_ZN7cocos2d10CCDirector9drawSceneEv", reinterpret_cast<void*>(&hkDrawScene),
         reinterpret_cast<void**>(&o_draw), nullptr},
        {"nativeTouchesBegin", "Java_org_cocos2dx_lib_Cocos2dxRenderer_nativeTouchesBegin",
         reinterpret_cast<void*>(&hkTouchBegin), reinterpret_cast<void**>(&o_begin), nullptr},
        {"nativeTouchesMove", "Java_org_cocos2dx_lib_Cocos2dxRenderer_nativeTouchesMove",
         reinterpret_cast<void*>(&hkTouchMove), reinterpret_cast<void**>(&o_move), nullptr},
        {"nativeTouchesEnd", "Java_org_cocos2dx_lib_Cocos2dxRenderer_nativeTouchesEnd",
         reinterpret_cast<void*>(&hkTouchEnd), reinterpret_cast<void**>(&o_end), nullptr},
        {"nativeTouchesCancel", "Java_org_cocos2dx_lib_Cocos2dxRenderer_nativeTouchesCancel",
         reinterpret_cast<void*>(&hkTouchCancel), reinterpret_cast<void**>(&o_cancel), nullptr},
    };

    std::string report;
    bool missing = false;
    for (Item& it : items) {
        it.address = dlsym(handle, it.symbol);
        if (!it.address) {
            missing = true;
            report += std::string("UI MISSING  ") + it.label + "  (" + it.symbol + " is not exported)\n";
            report += game::similarExports(it.label[0] == 'n' ? "nativeTouches" : "drawScene", "");
        }
    }
    if (missing) {
        report += "UI not installed: it needs every symbol above (a menu you cannot tap is useless).\n";
        return report;
    }

    g_invalidate = reinterpret_cast<InvalidateFn>(dlsym(handle, "_Z24ccGLInvalidateStateCachev"));
    if (!g_invalidate) report += "UI note: ccGLInvalidateStateCache not exported; GL state may glitch.\n";
    g_onSurvived = onSurvived;

    // Touch hooks first, drawing last: the menu only appears once it can be tapped.
    for (size_t i = 1; i < sizeof(items) / sizeof(items[0]); i++) {
        std::string err;
        if (!installHook(items[i].address, items[i].replacement, items[i].original, err)) {
            report += std::string("UI FAILED   ") + items[i].label + ": " + err + "\n";
            report += "UI not installed (hooks already placed stay inert: the menu is never drawn).\n";
            return report;
        }
        report += std::string("UI HOOKED   ") + items[i].label + "\n";
    }
    std::string err;
    if (!installHook(items[0].address, items[0].replacement, items[0].original, err)) {
        report += "UI FAILED   CCDirector::drawScene(): " + err + "\n";
        return report;
    }
    report += "UI HOOKED   CCDirector::drawScene()\n";
    g_installed.store(true);
    return report;
}

}  // namespace gdmm::ui

#else  // !GDMM_HAS_IMGUI

namespace gdmm::ui {

std::string installHooks(void*, void (*)()) {
    return "UI: ImGui was not available at build time (CMake could not fetch it); in-game menu not built.\n";
}

bool installed() { return false; }

}  // namespace gdmm::ui

#endif
