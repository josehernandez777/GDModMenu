#pragma once
#include <string>

namespace gdmm::ui {

/**
 * Installs the in-game menu (ImGui drawn after every frame, fed by the game's own touch events).
 * Needs libcocos2dcpp's drawScene and the four cocos touch JNI entry points, all looked up by exact name.
 * Installs nothing unless every required symbol is present. Returns a human-readable report.
 * Without ImGui compiled in (CMake could not fetch it) it only reports that.
 */
std::string installHooks(void* gameLibHandle, void (*onSurvived)());

bool installed();

}  // namespace gdmm::ui
