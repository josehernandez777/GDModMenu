#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace gdmm {

/** Implemented in payload.cpp: writes to logcat and gdmenu.log. */
void logMessage(const char* message);

namespace game {

/** One recorded/played input. tMs is game time since the level (re)start. button: 1 = jump. */
struct Event {
    int64_t tMs;
    bool down;
    int button;
    bool p2;
};

/** Gives the module the game's library handle and its exported symbol names (must outlive the process). */
void init(void* libHandle, const std::vector<std::string>* symbols, void (*onSurvived)());
void setDataDir(const std::string& dir);
void* libHandle();

/** Resolves each game function by EXACT mangled name and hooks it. Returns a human-readable report. */
std::string installHooks();
bool hooksInstalled();
std::string status();

/** Lists up to 5 exports containing both strings (used to suggest the right name when one is missing). */
std::string similarExports(const char* a, const char* b);

// Which functions are really hooked (the in-game menu only shows controls that can work).
bool canNoclip();
bool canSpeed();
bool canShake();
bool canDeathFx();
bool canMacro();

bool noclip();
void setNoclip(bool on);
float speed();
void setSpeed(float multiplier);
bool frozen();
void setFreeze(bool on);
void step();
bool noShake();
void setNoShake(bool on);
bool noDeathFx();
void setNoDeathFx(bool on);
float fps();

std::string macroState();
size_t macroRecordedCount();
size_t macroLoadedCount();
std::string macroRecord();
std::string macroStop();
std::string macroGet();
std::string macroSet(const std::vector<Event>& events);
std::string macroPlay();
std::string macroSave(int slot);
std::string macroLoad(int slot);

}  // namespace game
}  // namespace gdmm
