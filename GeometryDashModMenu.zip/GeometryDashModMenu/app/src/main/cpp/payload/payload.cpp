// libgdmenu_payload.so: injected INTO Geometry Dash (added as a DT_NEEDED dependency of
// libcocos2dcpp.so by tools/patch_gd_apk.sh). Works only on a patched copy of the game.
//
// Milestone 5 groundwork:
//   1. Runs inside the game process and waits for libcocos2dcpp.so.
//   2. Reads its exported symbol table and writes it to files (so real hooks can be written
//      against the REAL symbols of the target version instead of guesses).
//   3. Opens a loopback-only command server (127.0.0.1:38999) the companion app talks to.
// It does NOT hook or change game behaviour yet.
#include <android/log.h>
#include <arpa/inet.h>
#include <dlfcn.h>
#include <elf.h>
#include <link.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <unistd.h>

#include <cerrno>
#include <chrono>
#include <cstdarg>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

namespace {

constexpr const char* kTag = "GDMenu";
constexpr const char* kVersion = "0.1.0";
constexpr const char* kTargetLib = "libcocos2dcpp.so";
constexpr int kPort = 38999;
constexpr size_t kMaxSymbols = 600000;

std::mutex g_mutex;
std::string g_status = "starting";
std::string g_libPath;
std::vector<std::string> g_symbols;
std::string g_logDir;  // written before any other thread starts

void logf(const char* fmt, ...) {
    char msg[512];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(msg, sizeof(msg), fmt, ap);
    va_end(ap);
    __android_log_print(ANDROID_LOG_INFO, kTag, "%s", msg);
    if (!g_logDir.empty()) {
        std::string path = g_logDir + "/gdmenu.log";
        FILE* f = fopen(path.c_str(), "a");
        if (f) {
            fprintf(f, "%s\n", msg);
            fclose(f);
        }
    }
}

void setStatus(const std::string& s) {
    std::lock_guard<std::mutex> lock(g_mutex);
    g_status = s;
}

std::string packageName() {
    FILE* f = fopen("/proc/self/cmdline", "r");
    if (!f) return "";
    char buf[256] = {0};
    size_t n = fread(buf, 1, sizeof(buf) - 1, f);
    (void)n;
    fclose(f);
    return std::string(buf);
}

std::string pickLogDir(const std::string& pkg) {
    std::string root = "/storage/emulated/0/Android/data/" + pkg;
    std::string files = root + "/files";
    mkdir(root.c_str(), 0771);
    mkdir(files.c_str(), 0771);
    if (access(files.c_str(), W_OK) == 0) return files;
    return "/data/data/" + pkg;
}

struct LibInfo {
    bool found = false;
    std::string path;
    ElfW(Addr) bias = 0;
    const ElfW(Phdr)* phdr = nullptr;
    int phnum = 0;
};

int phdrCallback(dl_phdr_info* info, size_t, void* data) {
    auto* out = static_cast<LibInfo*>(data);
    if (info->dlpi_name && strstr(info->dlpi_name, kTargetLib)) {
        out->found = true;
        out->path = info->dlpi_name;
        out->bias = info->dlpi_addr;
        out->phdr = info->dlpi_phdr;
        out->phnum = info->dlpi_phnum;
        return 1;
    }
    return 0;
}

// Reads defined dynamic symbols of an already-loaded library straight from memory.
bool readExportedSymbols(const LibInfo& lib, std::vector<std::string>& out) {
    const ElfW(Dyn)* dyn = nullptr;
    for (int i = 0; i < lib.phnum; i++) {
        if (lib.phdr[i].p_type == PT_DYNAMIC) {
            dyn = reinterpret_cast<const ElfW(Dyn)*>(lib.bias + lib.phdr[i].p_vaddr);
            break;
        }
    }
    if (!dyn) return false;

    // Some linkers relocate d_ptr values in place, some do not; handle both.
    auto fix = [&](uintptr_t p) -> uintptr_t { return p < static_cast<uintptr_t>(lib.bias) ? p + lib.bias : p; };

    uintptr_t symtab = 0, strtab = 0, hash = 0, gnuHash = 0;
    for (; dyn->d_tag != DT_NULL; ++dyn) {
        switch (dyn->d_tag) {
            case DT_SYMTAB: symtab = fix(dyn->d_un.d_ptr); break;
            case DT_STRTAB: strtab = fix(dyn->d_un.d_ptr); break;
            case DT_HASH: hash = fix(dyn->d_un.d_ptr); break;
            case DT_GNU_HASH: gnuHash = fix(dyn->d_un.d_ptr); break;
            default: break;
        }
    }
    if (!symtab || !strtab) return false;

    size_t count = 0;
    if (hash) {
        count = reinterpret_cast<const uint32_t*>(hash)[1];  // nchain == number of symbols
    } else if (gnuHash) {
        const uint32_t* h = reinterpret_cast<const uint32_t*>(gnuHash);
        const uint32_t nbuckets = h[0];
        const uint32_t symoffset = h[1];
        const uint32_t bloomSize = h[2];
        const uint32_t* buckets = h + 4 + bloomSize * (sizeof(ElfW(Addr)) / 4);
        const uint32_t* chain = buckets + nbuckets;
        uint32_t maxIdx = 0;
        for (uint32_t i = 0; i < nbuckets; i++) {
            if (buckets[i] > maxIdx) maxIdx = buckets[i];
        }
        if (maxIdx < symoffset) {
            count = symoffset;
        } else {
            while (!(chain[maxIdx - symoffset] & 1u)) {
                maxIdx++;
                if (maxIdx > kMaxSymbols) return false;
            }
            count = static_cast<size_t>(maxIdx) + 1;
        }
    } else {
        return false;
    }
    if (count == 0 || count > kMaxSymbols) return false;

    const auto* syms = reinterpret_cast<const ElfW(Sym)*>(symtab);
    const char* str = reinterpret_cast<const char*>(strtab);
    out.reserve(count);
    for (size_t i = 1; i < count; i++) {
        if (syms[i].st_shndx == SHN_UNDEF || syms[i].st_name == 0) continue;
        out.emplace_back(str + syms[i].st_name);
    }
    return true;
}

void writeSymbolFiles(const std::vector<std::string>& syms) {
    static const char* kKeywords[] = {"PlayLayer", "GJBaseGameLayer", "PlayerObject", "CCScheduler", "CCDirector"};

    FILE* all = fopen((g_logDir + "/gdmenu_symbols_all.txt").c_str(), "w");
    FILE* gd = fopen((g_logDir + "/gdmenu_symbols_gd.txt").c_str(), "w");
    size_t filtered = 0;
    for (const auto& s : syms) {
        if (all) fprintf(all, "%s\n", s.c_str());
        for (const char* k : kKeywords) {
            if (s.find(k) != std::string::npos) {
                if (gd) fprintf(gd, "%s\n", s.c_str());
                filtered++;
                break;
            }
        }
    }
    if (all) fclose(all);
    if (gd) fclose(gd);
    logf("wrote symbol files: %zu total, %zu in gd list (dir: %s)", syms.size(), filtered, g_logDir.c_str());
}

std::string handleCommand(const std::string& line) {
    if (line == "PING") return "PONG\n";

    if (line == "STATUS") {
        std::lock_guard<std::mutex> lock(g_mutex);
        std::string r = "GDMenu payload ";
        r += kVersion;
        r += "\nstatus: " + g_status;
        r += "\nlib: " + (g_libPath.empty() ? std::string("(not found yet)") : g_libPath);
        r += "\nexported symbols: " + std::to_string(g_symbols.size());
        r += "\nfiles dir: " + g_logDir + "\n";
        return r;
    }

    if (line.rfind("SYMBOLS ", 0) == 0) {
        const std::string filter = line.substr(8);
        if (filter.empty()) return "ERR empty filter\n";
        std::lock_guard<std::mutex> lock(g_mutex);
        std::string body;
        size_t matches = 0, shown = 0;
        for (const auto& s : g_symbols) {
            if (s.find(filter) == std::string::npos) continue;
            matches++;
            if (shown < 40) {
                body += s + "\n";
                shown++;
            }
        }
        return "matches: " + std::to_string(matches) + " (showing " + std::to_string(shown) + ")\n" + body;
    }

    return "ERR unknown command\n";
}

void handleClient(int fd) {
    char buf[256];
    ssize_t n = recv(fd, buf, sizeof(buf) - 1, 0);
    if (n <= 0) return;
    buf[n] = 0;
    std::string line(buf);
    while (!line.empty() && (line.back() == '\n' || line.back() == '\r' || line.back() == ' ')) line.pop_back();
    const std::string reply = handleCommand(line);
    send(fd, reply.data(), reply.size(), MSG_NOSIGNAL);
}

void serverLoop() {
    int srv = socket(AF_INET, SOCK_STREAM, 0);
    if (srv < 0) {
        logf("server: socket() failed: %s", strerror(errno));
        return;
    }
    int one = 1;
    setsockopt(srv, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(kPort);
    addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);  // loopback only
    if (bind(srv, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) < 0 || listen(srv, 4) < 0) {
        logf("server: bind/listen failed on port %d: %s", kPort, strerror(errno));
        close(srv);
        return;
    }
    logf("server: listening on 127.0.0.1:%d", kPort);
    for (;;) {
        int c = accept(srv, nullptr, nullptr);
        if (c < 0) {
            if (errno == EINTR) continue;
            break;
        }
        timeval tv{2, 0};
        setsockopt(c, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
        handleClient(c);
        close(c);
    }
    close(srv);
}

void run() {
    const std::string pkg = packageName();
    g_logDir = pickLogDir(pkg);
    logf("payload %s loaded in process '%s'", kVersion, pkg.c_str());

    std::thread(serverLoop).detach();

    LibInfo lib;
    for (int i = 0; i < 360 && !lib.found; i++) {  // up to ~3 minutes
        dl_iterate_phdr(phdrCallback, &lib);
        if (!lib.found) std::this_thread::sleep_for(std::chrono::milliseconds(500));
    }
    if (!lib.found) {
        setStatus("error: libcocos2dcpp.so not found");
        logf("libcocos2dcpp.so not found");
        return;
    }
    logf("found %s at bias 0x%llx", lib.path.c_str(), static_cast<unsigned long long>(lib.bias));
    std::this_thread::sleep_for(std::chrono::seconds(2));

    std::vector<std::string> syms;
    if (!readExportedSymbols(lib, syms)) {
        setStatus("error: could not read symbol table");
        logf("could not read exported symbols");
        return;
    }
    writeSymbolFiles(syms);
    {
        std::lock_guard<std::mutex> lock(g_mutex);
        g_libPath = lib.path;
        g_symbols = std::move(syms);
        g_status = "ready (probe only: no hooks installed)";
    }
    logf("ready");
}

}  // namespace

__attribute__((constructor)) static void payloadInit() {
    std::thread(run).detach();
}
