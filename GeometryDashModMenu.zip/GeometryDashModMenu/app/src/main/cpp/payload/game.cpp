// Geometry Dash specific hooks. Every function is looked up by its exact mangled name in the
// game's real export table; nothing is hooked if the symbol is missing or the prologue is unsafe.
#include "payload/game.h"

#include <dlfcn.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <mutex>

#include "payload/hook.h"

namespace gdmm::game {
namespace {

enum State { kIdle = 0, kRecording = 1, kPlaying = 2 };
constexpr uint32_t kSurviveFrames = 600;

const std::vector<std::string>* g_syms = nullptr;
void* g_handle = nullptr;
void (*g_onSurvived)() = nullptr;
std::string g_dataDir;

std::mutex g_installMu;
std::mutex g_mu;  // protects g_rec, g_play, g_idx, g_clockMs
std::vector<Event> g_rec;
std::vector<Event> g_play;
size_t g_idx = 0;
double g_clockMs = 0.0;

std::atomic<bool> g_noclip{false};
std::atomic<bool> g_noShake{false};
std::atomic<bool> g_noDeathFx{false};
std::atomic<bool> g_freeze{false};
std::atomic<int> g_stepPending{0};
std::atomic<float> g_speed{1.0f};
std::atomic<float> g_fps{0.0f};
std::atomic<int> g_state{kIdle};
std::atomic<void*> g_playLayer{nullptr};
std::atomic<uint32_t> g_frames{0};

using UpdateFn = void (*)(void*, float);
using ButtonFn = void (*)(void*, int, bool);
using DestroyFn = void (*)(void*, void*, void*);
using VoidFn = void (*)(void*);
using ShakeFn = void (*)(void*, float, float, float);

UpdateFn o_update = nullptr;
ButtonFn o_push = nullptr;
ButtonFn o_release = nullptr;
DestroyFn o_destroy = nullptr;
VoidFn o_reset = nullptr;
UpdateFn o_sched = nullptr;
ShakeFn o_shake = nullptr;
VoidFn o_deathFx = nullptr;

void recordEvent(bool down, int button, bool isPlayer1) {
    if (g_state.load() != kRecording) return;
    std::lock_guard<std::mutex> lock(g_mu);
    g_rec.push_back({static_cast<int64_t>(g_clockMs), down, button, !isPlayer1});
}

// ---- replacements (run on the game's own threads) ----

void hkUpdate(void* self, float dt) {
    g_playLayer.store(self);

    std::vector<Event> due;
    if (g_state.load() == kPlaying) {
        std::lock_guard<std::mutex> lock(g_mu);
        while (g_idx < g_play.size() && static_cast<double>(g_play[g_idx].tMs) <= g_clockMs) {
            due.push_back(g_play[g_idx++]);
        }
    }
    for (const Event& e : due) {
        ButtonFn fn = e.down ? o_push : o_release;  // originals: injected input is not re-recorded
        if (fn) fn(self, e.button, !e.p2);
    }

    if (o_update) o_update(self, dt);

    {
        std::lock_guard<std::mutex> lock(g_mu);
        g_clockMs += static_cast<double>(dt) * 1000.0;
    }
    if (g_frames.fetch_add(1) + 1 == kSurviveFrames && g_onSurvived) g_onSurvived();
}

void hkPush(void* self, int button, bool isPlayer1) {
    recordEvent(true, button, isPlayer1);
    if (o_push) o_push(self, button, isPlayer1);
}

void hkRelease(void* self, int button, bool isPlayer1) {
    recordEvent(false, button, isPlayer1);
    if (o_release) o_release(self, button, isPlayer1);
}

void hkDestroyPlayer(void* self, void* player, void* object) {
    if (g_noclip.load()) return;  // the player is never destroyed
    if (o_destroy) o_destroy(self, player, object);
}

void hkResetLevel(void* self) {
    if (o_reset) o_reset(self);
    std::lock_guard<std::mutex> lock(g_mu);
    g_clockMs = 0.0;
    g_idx = 0;
    if (g_state.load() == kRecording) g_rec.clear();
}

// Speedhack / freeze / frame step: scale the delta time the whole game receives from cocos2d's scheduler.
void hkSchedulerUpdate(void* self, float dt) {
    using Clock = std::chrono::steady_clock;
    static Clock::time_point windowStart = Clock::now();
    static int windowFrames = 0;
    if (++windowFrames >= 30) {
        const auto now = Clock::now();
        const double secs = std::chrono::duration<double>(now - windowStart).count();
        if (secs > 0.0) g_fps.store(static_cast<float>(windowFrames / secs));
        windowStart = now;
        windowFrames = 0;
    }
    float d = dt * g_speed.load();
    if (g_freeze.load()) d = g_stepPending.exchange(0) > 0 ? (1.0f / 60.0f) : 0.0f;
    if (o_sched) o_sched(self, d);
}

void hkShakeCamera(void* self, float a, float b, float c) {
    if (g_noShake.load()) return;
    if (o_shake) o_shake(self, a, b, c);
}

void hkPlayDeathEffect(void* self) {
    if (g_noDeathFx.load()) return;
    if (o_deathFx) o_deathFx(self);
}

struct Spec {
    const char* label;
    const char* symbol;     // exact mangled name
    const char* hintClass;  // used only to suggest similar exports when missing
    const char* hintFn;
    void* replacement;
    void** original;
    bool installed;
};

Spec g_specs[] = {
    {"PlayLayer::update(float)", "_ZN9PlayLayer6updateEf", "PlayLayer", "update",
     reinterpret_cast<void*>(&hkUpdate), reinterpret_cast<void**>(&o_update), false},
    {"GJBaseGameLayer::pushButton(int,bool)", "_ZN15GJBaseGameLayer10pushButtonEib", "GJBaseGameLayer", "pushButton",
     reinterpret_cast<void*>(&hkPush), reinterpret_cast<void**>(&o_push), false},
    {"GJBaseGameLayer::releaseButton(int,bool)", "_ZN15GJBaseGameLayer13releaseButtonEib", "GJBaseGameLayer",
     "releaseButton", reinterpret_cast<void*>(&hkRelease), reinterpret_cast<void**>(&o_release), false},
    {"PlayLayer::destroyPlayer(PlayerObject*,GameObject*)",
     "_ZN9PlayLayer13destroyPlayerEP12PlayerObjectP10GameObject", "PlayLayer", "destroyPlayer",
     reinterpret_cast<void*>(&hkDestroyPlayer), reinterpret_cast<void**>(&o_destroy), false},
    {"PlayLayer::resetLevel()", "_ZN9PlayLayer10resetLevelEv", "PlayLayer", "resetLevel",
     reinterpret_cast<void*>(&hkResetLevel), reinterpret_cast<void**>(&o_reset), false},
    {"cocos2d::CCScheduler::update(float)", "_ZN7cocos2d11CCScheduler6updateEf", "CCScheduler", "update",
     reinterpret_cast<void*>(&hkSchedulerUpdate), reinterpret_cast<void**>(&o_sched), false},
    {"GJBaseGameLayer::shakeCamera(float,float,float)", "_ZN15GJBaseGameLayer11shakeCameraEfff", "GJBaseGameLayer",
     "shakeCamera", reinterpret_cast<void*>(&hkShakeCamera), reinterpret_cast<void**>(&o_shake), false},
    {"PlayerObject::playDeathEffect()", "_ZN12PlayerObject15playDeathEffectEv", "PlayerObject", "playDeathEffect",
     reinterpret_cast<void*>(&hkPlayDeathEffect), reinterpret_cast<void**>(&o_deathFx), false},
};

bool allInputHooks() { return o_update && o_push && o_release; }

std::string slotPath(int slot) { return g_dataDir + "/macro_" + std::to_string(slot) + ".txt"; }

}  // namespace

void init(void* libHandle, const std::vector<std::string>* symbols, void (*onSurvived)()) {
    g_handle = libHandle;
    g_syms = symbols;
    g_onSurvived = onSurvived;
}

void setDataDir(const std::string& dir) { g_dataDir = dir; }
void* libHandle() { return g_handle; }

std::string similarExports(const char* cls, const char* fn) {
    std::string out;
    int shown = 0;
    if (!g_syms) return out;
    for (const auto& s : *g_syms) {
        if (s.find(cls) != std::string::npos && s.find(fn) != std::string::npos) {
            out += "    similar export: " + s + "\n";
            if (++shown >= 5) break;
        }
    }
    if (shown == 0) out += "    no export contains both '" + std::string(cls) + "' and '" + fn + "'\n";
    return out;
}

bool hooksInstalled() {
    for (const Spec& s : g_specs) {
        if (s.installed) return true;
    }
    return false;
}

std::string installHooks() {
    std::lock_guard<std::mutex> lock(g_installMu);
    if (!g_handle) return "ERROR: game library not ready yet\n";
    std::string report;
    char buf[160];
    for (Spec& s : g_specs) {
        if (s.installed) {
            report += std::string("ALREADY  ") + s.label + "\n";
            continue;
        }
        void* addr = dlsym(g_handle, s.symbol);
        if (!addr) {
            report += std::string("MISSING  ") + s.label + "  (" + s.symbol + " is not exported)\n";
            report += similarExports(s.hintClass, s.hintFn);
            continue;
        }
        std::string err;
        if (installHook(addr, s.replacement, s.original, err)) {
            s.installed = true;
            snprintf(buf, sizeof(buf), "HOOKED   %s @%p\n", s.label, addr);
            report += buf;
        } else {
            report += std::string("FAILED   ") + s.label + ": " + err + "\n";
        }
    }
    gdmm::logMessage(report.c_str());
    return report;
}

std::string status() {
    std::string r;
    for (const Spec& s : g_specs) {
        r += std::string(s.installed ? "  [hooked]  " : "  [not hooked]  ") + s.label + "\n";
    }
    char buf[256];
    snprintf(buf, sizeof(buf),
             "noclip: %s | speed: %.2fx | freeze: %s | no shake: %s | no death effect: %s | fps: %.1f\n",
             g_noclip.load() ? "ON" : "OFF", g_speed.load(), g_freeze.load() ? "ON" : "OFF",
             g_noShake.load() ? "ON" : "OFF", g_noDeathFx.load() ? "ON" : "OFF", g_fps.load());
    r += buf;
    r += "macro: " + macroState() + " | recorded " + std::to_string(macroRecordedCount()) + " | loaded " +
         std::to_string(macroLoadedCount()) + "\n";
    snprintf(buf, sizeof(buf), "PlayLayer seen: %s | frames run by hooked update: %u\n",
             g_playLayer.load() ? "yes" : "no", g_frames.load());
    r += buf;
    return r;
}

bool canNoclip() { return o_destroy != nullptr; }
bool canSpeed() { return o_sched != nullptr; }
bool canShake() { return o_shake != nullptr; }
bool canDeathFx() { return o_deathFx != nullptr; }
bool canMacro() { return allInputHooks(); }

bool noclip() { return g_noclip.load(); }
void setNoclip(bool on) { g_noclip.store(on); }
float speed() { return g_speed.load(); }
void setSpeed(float m) { g_speed.store(std::min(10.0f, std::max(0.05f, m))); }
bool frozen() { return g_freeze.load(); }
void setFreeze(bool on) {
    g_stepPending.store(0);
    g_freeze.store(on);
}
void step() {
    if (g_freeze.load()) g_stepPending.store(1);
}
bool noShake() { return g_noShake.load(); }
void setNoShake(bool on) { g_noShake.store(on); }
bool noDeathFx() { return g_noDeathFx.load(); }
void setNoDeathFx(bool on) { g_noDeathFx.store(on); }
float fps() { return g_fps.load(); }

std::string macroState() {
    const int st = g_state.load();
    return st == kRecording ? "RECORDING" : st == kPlaying ? "PLAYING" : "idle";
}

size_t macroRecordedCount() {
    std::lock_guard<std::mutex> lock(g_mu);
    return g_rec.size();
}

size_t macroLoadedCount() {
    std::lock_guard<std::mutex> lock(g_mu);
    return g_play.size();
}

std::string macroRecord() {
    if (!allInputHooks()) return "ERR: needs hooks on update, pushButton and releaseButton (see STATUS)\n";
    std::lock_guard<std::mutex> lock(g_mu);
    g_rec.clear();
    g_clockMs = 0.0;
    g_state.store(kRecording);
    return "OK recording (time zero = now; resets on every level restart)\n";
}

std::string macroStop() {
    const int was = g_state.exchange(kIdle);
    char buf[96];
    snprintf(buf, sizeof(buf), "OK stopped (%s), %zu events recorded\n",
             was == kRecording ? "was recording" : was == kPlaying ? "was playing" : "was idle", macroRecordedCount());
    return buf;
}

std::string macroGet() {
    std::lock_guard<std::mutex> lock(g_mu);
    std::string out = "events " + std::to_string(g_rec.size()) + "\n";
    char buf[64];
    for (const Event& e : g_rec) {
        snprintf(buf, sizeof(buf), "%lld,%c,%d,%d\n", static_cast<long long>(e.tMs), e.down ? 'D' : 'U', e.button,
                 e.p2 ? 1 : 0);
        out += buf;
    }
    return out;
}

std::string macroSet(const std::vector<Event>& events) {
    int64_t last = 0;
    for (const Event& e : events) {
        if (e.tMs < 0 || e.tMs < last) return "ERR: event times must be >= 0 and sorted\n";
        if (e.button < 1 || e.button > 3) return "ERR: button must be 1..3\n";
        last = e.tMs;
    }
    std::lock_guard<std::mutex> lock(g_mu);
    g_play = events;
    g_idx = 0;
    return "OK loaded " + std::to_string(events.size()) + " events\n";
}

std::string macroPlay() {
    if (!allInputHooks()) return "ERR: needs hooks on update, pushButton and releaseButton (see STATUS)\n";
    std::lock_guard<std::mutex> lock(g_mu);
    if (g_play.empty()) return "ERR: no macro loaded (Load a slot or use MACRO SET first)\n";
    g_idx = 0;
    g_clockMs = 0.0;
    g_state.store(kPlaying);
    return "OK playing (time zero = now; restarts at every level restart)\n";
}

// File format (documented in docs/MACRO_FORMAT.md): first line "GDMM-MACRO 1", then "timeMs,D|U,button,p2".
std::string macroSave(int slot) {
    if (g_dataDir.empty()) return "ERR: no data directory\n";
    std::vector<Event> events;
    {
        std::lock_guard<std::mutex> lock(g_mu);
        events = g_rec.empty() ? g_play : g_rec;  // last recording, or the loaded macro if nothing was recorded
    }
    if (events.empty()) return "ERR: nothing to save\n";
    FILE* f = fopen(slotPath(slot).c_str(), "w");
    if (!f) return "ERR: cannot write " + slotPath(slot) + "\n";
    fprintf(f, "GDMM-MACRO 1\n");
    for (const Event& e : events) {
        fprintf(f, "%lld,%c,%d,%d\n", static_cast<long long>(e.tMs), e.down ? 'D' : 'U', e.button, e.p2 ? 1 : 0);
    }
    fclose(f);
    return "OK saved " + std::to_string(events.size()) + " events to slot " + std::to_string(slot) + "\n";
}

std::string macroLoad(int slot) {
    FILE* f = fopen(slotPath(slot).c_str(), "r");
    if (!f) return "ERR: slot " + std::to_string(slot) + " is empty\n";
    char line[128];
    std::vector<Event> events;
    bool header = false, ok = true;
    while (fgets(line, sizeof(line), f)) {
        if (!header) {
            header = strncmp(line, "GDMM-MACRO 1", 12) == 0;
            if (!header) {
                ok = false;
                break;
            }
            continue;
        }
        long long t = 0;
        char type = 0;
        int button = 0, p2 = 0;
        if (sscanf(line, "%lld,%c,%d,%d", &t, &type, &button, &p2) != 4 || (type != 'D' && type != 'U')) {
            ok = false;
            break;
        }
        events.push_back({static_cast<int64_t>(t), type == 'D', button, p2 != 0});
    }
    fclose(f);
    if (!ok || !header) return "ERR: slot file is not a valid macro\n";
    return macroSet(events);
}

}  // namespace gdmm::game
