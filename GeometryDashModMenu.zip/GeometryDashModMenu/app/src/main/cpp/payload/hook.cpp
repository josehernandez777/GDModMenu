#include "payload/hook.h"

#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>

#include <cstdio>
#include <cstring>
#include <mutex>

namespace gdmm {

bool isPcRelativeArm64(uint32_t i) {
    return (i & 0x7C000000u) == 0x14000000u ||  // B, BL
           (i & 0xFF000010u) == 0x54000000u ||  // B.cond
           (i & 0x7E000000u) == 0x34000000u ||  // CBZ, CBNZ
           (i & 0x7E000000u) == 0x36000000u ||  // TBZ, TBNZ
           (i & 0x1F000000u) == 0x10000000u ||  // ADR, ADRP
           (i & 0x3B000000u) == 0x18000000u;    // LDR (literal)
}

bool isRegisterBranchArm64(uint32_t i) {
    const uint32_t m = i & 0xFFFFFC1Fu;
    return m == 0xD61F0000u || m == 0xD63F0000u || m == 0xD65F0000u;  // BR, BLR, RET
}

bool patchMemory(void* addr, const void* data, size_t len) {
    const uintptr_t ps = static_cast<uintptr_t>(sysconf(_SC_PAGESIZE));
    const uintptr_t a = reinterpret_cast<uintptr_t>(addr);
    const uintptr_t start = a & ~(ps - 1);
    const uintptr_t end = (a + len + ps - 1) & ~(ps - 1);
    bool ok = false;
    if (mprotect(reinterpret_cast<void*>(start), end - start, PROT_READ | PROT_WRITE | PROT_EXEC) == 0) {
        memcpy(addr, data, len);
        mprotect(reinterpret_cast<void*>(start), end - start, PROT_READ | PROT_EXEC);
        ok = true;
    } else {
        // Fallback: write through /proc/self/mem (works on private file mappings without mprotect).
        int fd = open("/proc/self/mem", O_RDWR | O_CLOEXEC);
        if (fd >= 0) {
            ok = pwrite(fd, data, len, static_cast<off_t>(a)) == static_cast<ssize_t>(len);
            close(fd);
        }
    }
    if (ok) __builtin___clear_cache(reinterpret_cast<char*>(addr), reinterpret_cast<char*>(addr) + len);
    return ok;
}

#if defined(__aarch64__)

namespace {

constexpr size_t kPatchBytes = 16;  // ldr x17,#8 ; br x17 ; .quad target
constexpr size_t kSlotBytes = 32;   // 16 copied bytes + 16 bytes jump back
constexpr uint32_t kLdrX17 = 0x58000051u;  // ldr x17, #8
constexpr uint32_t kBrX17 = 0xD61F0220u;   // br x17

uint8_t* allocTrampoline() {
    static std::mutex mu;
    static uint8_t* arena = nullptr;
    static size_t used = 0;
    std::lock_guard<std::mutex> lock(mu);
    constexpr size_t kArena = 4096;
    if (!arena || used + kSlotBytes > kArena) {
        void* p = mmap(nullptr, kArena, PROT_READ | PROT_WRITE | PROT_EXEC, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        if (p == MAP_FAILED) return nullptr;
        arena = static_cast<uint8_t*>(p);
        used = 0;
    }
    uint8_t* slot = arena + used;
    used += kSlotBytes;
    return slot;
}

}  // namespace

bool installHook(void* target, void* replacement, void** original, std::string& err) {
    uint32_t insn[4];
    memcpy(insn, target, kPatchBytes);
    for (int i = 0; i < 4; i++) {
        if (isPcRelativeArm64(insn[i])) {
            char buf[96];
            snprintf(buf, sizeof(buf), "pc-relative instruction 0x%08x at +%d (cannot copy safely)", insn[i], i * 4);
            err = buf;
            return false;
        }
        if (i < 3 && isRegisterBranchArm64(insn[i])) {
            err = "function is shorter than 16 bytes";
            return false;
        }
    }
    uint8_t* tramp = allocTrampoline();
    if (!tramp) {
        err = "could not allocate trampoline memory";
        return false;
    }
    memcpy(tramp, insn, kPatchBytes);
    const uint64_t back = reinterpret_cast<uint64_t>(target) + kPatchBytes;
    memcpy(tramp + 16, &kLdrX17, 4);
    memcpy(tramp + 20, &kBrX17, 4);
    memcpy(tramp + 24, &back, 8);
    __builtin___clear_cache(reinterpret_cast<char*>(tramp), reinterpret_cast<char*>(tramp) + kSlotBytes);

    uint8_t hook[kPatchBytes];
    const uint64_t rep = reinterpret_cast<uint64_t>(replacement);
    memcpy(hook, &kLdrX17, 4);
    memcpy(hook + 4, &kBrX17, 4);
    memcpy(hook + 8, &rep, 8);

    *original = tramp;  // set before patching: the replacement may be called immediately
    if (!patchMemory(target, hook, kPatchBytes)) {
        *original = nullptr;
        err = "could not write to code memory";
        return false;
    }
    return true;
}

#else

bool installHook(void*, void*, void**, std::string& err) {
    err = "inline hooks are only implemented for arm64-v8a";
    return false;
}

#endif

}  // namespace gdmm
