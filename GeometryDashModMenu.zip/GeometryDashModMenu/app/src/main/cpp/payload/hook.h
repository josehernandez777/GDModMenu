#pragma once
#include <cstddef>
#include <cstdint>
#include <string>

namespace gdmm {

/** Writes [len] bytes into (possibly read-only) code memory and flushes the instruction cache. */
bool patchMemory(void* addr, const void* data, size_t len);

/**
 * Inline hook of a function entry. Only implemented for arm64-v8a.
 * On success *original points to a trampoline that runs the original function.
 * Refuses (returns false, fills err) instead of guessing when the first 16 bytes of the
 * function cannot be copied safely (pc-relative instructions, function too short).
 */
bool installHook(void* target, void* replacement, void** original, std::string& err);

/** True for arm64 instructions whose meaning depends on their own address (cannot be copied verbatim). */
bool isPcRelativeArm64(uint32_t insn);

/** True for arm64 BR/BLR/RET. */
bool isRegisterBranchArm64(uint32_t insn);

}  // namespace gdmm
