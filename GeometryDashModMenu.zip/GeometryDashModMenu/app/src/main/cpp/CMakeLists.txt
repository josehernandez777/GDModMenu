cmake_minimum_required(VERSION 3.18.1)
project(gdmodmenu LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

add_library(gdmodmenu SHARED
    native-lib.cpp
    core/native_info.cpp
)

target_include_directories(gdmodmenu PRIVATE ${CMAKE_CURRENT_SOURCE_DIR})
target_compile_options(gdmodmenu PRIVATE -Wall -Wextra)

# Payload injected into Geometry Dash (see tools/patch_gd_apk.sh). Separate from the app's own bridge library.
add_library(gdmenu_payload SHARED payload/payload.cpp payload/game.cpp payload/hook.cpp payload/ui.cpp)
target_include_directories(gdmenu_payload PRIVATE ${CMAKE_CURRENT_SOURCE_DIR})
target_compile_options(gdmenu_payload PRIVATE -Wall -Wextra)
target_link_libraries(gdmenu_payload log)

# In-game menu: Dear ImGui, fetched at configure time. If the tag cannot be reached the payload still builds
# (without the in-game menu) and tells so in the UI install report.
set(GDMM_IMGUI_TAG v1.90.9)
execute_process(
    COMMAND git ls-remote --exit-code --tags https://github.com/ocornut/imgui.git ${GDMM_IMGUI_TAG}
    RESULT_VARIABLE GDMM_IMGUI_CHECK
    OUTPUT_QUIET ERROR_QUIET)
if(GDMM_IMGUI_CHECK EQUAL 0)
    include(FetchContent)
    FetchContent_Declare(imgui
        GIT_REPOSITORY https://github.com/ocornut/imgui.git
        GIT_TAG ${GDMM_IMGUI_TAG}
        GIT_SHALLOW TRUE)
    FetchContent_MakeAvailable(imgui)
    target_sources(gdmenu_payload PRIVATE
        ${imgui_SOURCE_DIR}/imgui.cpp
        ${imgui_SOURCE_DIR}/imgui_draw.cpp
        ${imgui_SOURCE_DIR}/imgui_tables.cpp
        ${imgui_SOURCE_DIR}/imgui_widgets.cpp
        ${imgui_SOURCE_DIR}/backends/imgui_impl_opengl3.cpp)
    target_include_directories(gdmenu_payload PRIVATE ${imgui_SOURCE_DIR} ${imgui_SOURCE_DIR}/backends)
    target_compile_definitions(gdmenu_payload PRIVATE GDMM_HAS_IMGUI=1 IMGUI_IMPL_OPENGL_ES2=1)
    target_link_libraries(gdmenu_payload GLESv2)
else()
    message(WARNING "Dear ImGui ${GDMM_IMGUI_TAG} not reachable: building the payload without the in-game menu")
endif()
