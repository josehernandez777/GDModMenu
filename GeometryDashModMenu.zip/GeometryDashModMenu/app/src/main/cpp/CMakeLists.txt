cmake_minimum_required(VERSION 3.18.1)
project(gdmodmenu LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

add_library(gdmodmenu SHARED
    native-lib.cpp
    core/native_info.cpp
)

target_include_directories(gdmodmenu PRIVATE ${CMAKE_CURRENT_SOURCE_DIR})
target_compile_options(gdmodmenu PRIVATE -Wall -Wextra)
