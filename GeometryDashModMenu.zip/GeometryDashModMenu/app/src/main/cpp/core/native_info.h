#pragma once

namespace gdmm::core {

/** Native library version. */
const char* version();

/** ABI this binary was compiled for. */
const char* abi();

/** Deterministic function used to verify the JNI round trip. Mirrors NativeBridge.expectedSelfTest. */
int selfTest(int x);

}  // namespace gdmm::core
