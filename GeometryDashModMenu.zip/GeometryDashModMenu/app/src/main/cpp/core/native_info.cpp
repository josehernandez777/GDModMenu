#include "core/native_info.h"

namespace gdmm::core {

const char* version() { return "0.1.0"; }

const char* abi() {
#if defined(__aarch64__)
    return "arm64-v8a";
#elif defined(__arm__)
    return "armeabi-v7a";
#elif defined(__x86_64__)
    return "x86_64";
#elif defined(__i386__)
    return "x86";
#else
    return "unknown";
#endif
}

int selfTest(int x) { return x * 2 + 1; }

}  // namespace gdmm::core
