#include <jni.h>

#include "core/native_info.h"

// JNI entry points for com.example.gdmodmenu.nativebridge.NativeBridge

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_gdmodmenu_nativebridge_NativeBridge_nativeVersion(JNIEnv* env, jobject /*thiz*/) {
    return env->NewStringUTF(gdmm::core::version());
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_gdmodmenu_nativebridge_NativeBridge_nativeAbi(JNIEnv* env, jobject /*thiz*/) {
    return env->NewStringUTF(gdmm::core::abi());
}

extern "C" JNIEXPORT jint JNICALL
Java_com_example_gdmodmenu_nativebridge_NativeBridge_nativeSelfTest(JNIEnv* /*env*/, jobject /*thiz*/, jint x) {
    return static_cast<jint>(gdmm::core::selfTest(static_cast<int>(x)));
}
