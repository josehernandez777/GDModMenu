package com.example.gdmodmenu.macros

/** Pure editing operations. Lists are immutable; every function returns a new, time-sorted list. */
object MacroEditing {

    fun setTime(events: List<MacroEvent>, index: Int, newTimeMs: Long): List<MacroEvent> {
        require(index in events.indices) { "index out of range" }
        require(newTimeMs >= 0) { "time must be >= 0" }
        val list = events.toMutableList()
        list[index] = list[index].copy(timeMs = newTimeMs)
        return list.sortedBy { it.timeMs }
    }

    fun remove(events: List<MacroEvent>, index: Int): List<MacroEvent> {
        require(index in events.indices) { "index out of range" }
        return events.filterIndexed { i, _ -> i != index }
    }

    /** Inserts a DOWN at [timeMs] and the matching UP [durationMs] later. */
    fun insertTap(events: List<MacroEvent>, timeMs: Long, x: Float, y: Float, durationMs: Long): List<MacroEvent> {
        require(timeMs >= 0) { "time must be >= 0" }
        require(durationMs > 0) { "duration must be > 0" }
        val down = MacroEvent(timeMs, EventType.DOWN, x.coerceIn(0f, 1f), y.coerceIn(0f, 1f))
        val up = down.copy(timeMs = timeMs + durationMs, type = EventType.UP)
        return (events + down + up).sortedBy { it.timeMs }
    }
}
