package com.example.gdmodmenu.ui

import android.content.Context
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import com.example.gdmodmenu.macros.EventType
import com.example.gdmodmenu.macros.Macro
import com.example.gdmodmenu.macros.MacroController
import com.example.gdmodmenu.macros.MacroEditing
import com.example.gdmodmenu.macros.MacroEvent
import com.example.gdmodmenu.macros.MacroPlayer
import com.example.gdmodmenu.settings.SettingDefaults
import com.example.gdmodmenu.settings.SettingsStore
import com.google.android.material.button.MaterialButton
import com.google.android.material.progressindicator.LinearProgressIndicator
import java.util.Locale
import java.util.UUID

/**
 * Macro bot UI: record, save, load, rename, duplicate, delete, edit events and play back
 * inside the app's own test pad. (Playback into Geometry Dash is NOT part of this page.)
 */
class MacrosPage(private val context: Context) {

    private val c = MacroController
    private val status = bodyText(context, "")
    private val pad = TestPadView(context)
    private val progress = LinearProgressIndicator(context)
    private val nameInput = EditText(context)
    private val dynamic = LinearLayout(context)
    private lateinit var recordButton: MaterialButton
    private lateinit var pauseButton: MaterialButton

    fun addTo(column: LinearLayout) {
        c.owner = this

        pad.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, context.dp(200))
            .apply { bottomMargin = context.dp(12) }
        progress.max = 1000
        progress.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = context.dp(8) }
        nameInput.apply {
            setText(c.currentName)
            setSingleLine()
            hint = "Macro name"
        }
        dynamic.orientation = LinearLayout.VERTICAL

        recordButton = smallButton(context, "Record") { toggleRecord() }
        pauseButton = smallButton(context, "Pause") { togglePause() }

        pad.onPadTouch = { type, x, y -> c.recorder.add(type, x, y) }
        c.player.onEvent = { e -> pad.showTap(e.x, e.y, e.type == EventType.DOWN) }
        c.player.onProgress = { p -> progress.progress = (p * 1000).toInt() }
        c.player.onFinished = {
            pad.clearHeld()
            progress.progress = 1000
            refreshStatus()
        }
        pad.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) = Unit
            override fun onViewDetachedFromWindow(v: View) {
                if (c.owner !== this@MacrosPage) return // a newer page already took over
                c.player.stop()
                if (c.recorder.isRecording) c.events = c.recorder.stop()
                c.player.onEvent = null
                c.player.onProgress = null
                c.player.onFinished = null
                c.owner = null
            }
        })

        column.addView(
            bodyText(
                context,
                "Test environment: record taps on the pad, then play them back. " +
                    "This does not control Geometry Dash.",
                muted = true
            ).apply { setPadding(0, 0, 0, context.dp(10)) }
        )
        column.addView(pad)
        column.addView(progress)
        column.addView(status.apply { setPadding(0, 0, 0, context.dp(10)) })
        column.addView(row(context, recordButton, smallButton(context, "New") { newMacro() }))
        column.addView(
            row(
                context,
                smallButton(context, "Play") { play() },
                pauseButton,
                smallButton(context, "Stop") { stopPlayback() },
                smallButton(context, "Restart") { restart() }
            )
        )
        column.addView(nameInput)
        column.addView(smallButton(context, "Save macro") { save() }.apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = context.dp(8) }
        })
        column.addView(dynamic)
        render()
    }

    // ---- actions ----

    private fun toggleRecord() {
        if (c.recorder.isRecording) {
            c.events = c.recorder.stop()
            toast(context, "Recorded ${c.events.size} events")
        } else {
            c.player.stop()
            c.currentId = null
            c.recorder.start()
        }
        render()
    }

    private fun newMacro() {
        if (c.recorder.isRecording) c.recorder.stop()
        c.newMacro()
        nameInput.setText(c.currentName)
        pad.clearHeld()
        progress.progress = 0
        render()
    }

    private fun play() {
        if (c.recorder.isRecording) {
            toast(context, "Stop recording first")
            return
        }
        if (c.events.isEmpty()) {
            toast(context, "Nothing to play: record or load a macro")
            return
        }
        c.player.speed = SettingsStore.model.getInt(SettingDefaults.PLAYBACK_SPEED) / 100f
        if (c.player.state == MacroPlayer.State.PAUSED) c.player.resume() else c.player.start(c.events)
        refreshStatus()
    }

    private fun togglePause() {
        when (c.player.state) {
            MacroPlayer.State.PLAYING -> c.player.pause()
            MacroPlayer.State.PAUSED -> {
                c.player.speed = SettingsStore.model.getInt(SettingDefaults.PLAYBACK_SPEED) / 100f
                c.player.resume()
            }
            MacroPlayer.State.IDLE -> Unit
        }
        refreshStatus()
    }

    private fun stopPlayback() {
        c.player.stop()
        pad.clearHeld()
        progress.progress = 0
        refreshStatus()
    }

    private fun restart() {
        if (c.recorder.isRecording || c.events.isEmpty()) return
        c.player.speed = SettingsStore.model.getInt(SettingDefaults.PLAYBACK_SPEED) / 100f
        c.player.start(c.events)
        refreshStatus()
    }

    private fun save() {
        if (c.recorder.isRecording) {
            toast(context, "Stop recording first")
            return
        }
        if (c.events.isEmpty()) {
            toast(context, "Nothing to save")
            return
        }
        val name = nameInput.text.toString().trim().ifEmpty { "Macro" }
        c.currentName = name
        val macro = Macro(
            id = c.currentId ?: UUID.randomUUID().toString(),
            name = name,
            createdAt = System.currentTimeMillis(),
            events = c.events
        )
        try {
            c.repository.save(macro)
            c.currentId = macro.id
            toast(context, "Saved")
        } catch (e: Exception) {
            toast(context, "Could not save: ${e.message}")
        }
        render()
    }

    private fun load(m: Macro) {
        c.player.stop()
        c.currentId = m.id
        c.currentName = m.name
        c.events = m.events
        nameInput.setText(m.name)
        progress.progress = 0
        render()
    }

    private fun rename(m: Macro) {
        promptText(context, "Rename macro", m.name, false) { n ->
            if (n.isBlank()) {
                toast(context, "Name is empty")
            } else {
                c.repository.rename(m.id, n)
                if (c.currentId == m.id) {
                    c.currentName = n.trim()
                    nameInput.setText(c.currentName)
                }
                render()
            }
        }
    }

    private fun duplicate(m: Macro) {
        c.repository.duplicate(m.id)
        render()
    }

    private fun delete(m: Macro) {
        c.repository.delete(m.id)
        if (c.currentId == m.id) c.currentId = null
        render()
    }

    private fun editTime(index: Int) {
        promptText(context, "Event time (ms)", c.events[index].timeMs.toString(), true) { s ->
            val t = s.toLongOrNull()
            if (t == null || t < 0) {
                toast(context, "Invalid time")
            } else {
                c.player.stop()
                c.events = MacroEditing.setTime(c.events, index, t)
                render()
            }
        }
    }

    private fun deleteEvent(index: Int) {
        c.player.stop()
        c.events = MacroEditing.remove(c.events, index)
        render()
    }

    private fun insertTap() {
        promptText(context, "Insert tap at time (ms)", "0", true) { s ->
            val t = s.toLongOrNull()
            if (t == null || t < 0) {
                toast(context, "Invalid time")
            } else {
                c.player.stop()
                val duration = SettingsStore.model.getInt(SettingDefaults.TAP_MS).toLong()
                c.events = MacroEditing.insertTap(c.events, t, 0.5f, 0.5f, duration)
                render()
            }
        }
    }

    // ---- rendering ----

    private fun refreshStatus() {
        val state = when {
            c.recorder.isRecording -> "RECORDING: tap the pad"
            c.player.state == MacroPlayer.State.PLAYING -> "PLAYING"
            c.player.state == MacroPlayer.State.PAUSED -> "PAUSED"
            else -> "Idle"
        }
        status.text = "$state · '${c.currentName}' · ${c.events.size} events"
        recordButton.text = if (c.recorder.isRecording) "Stop recording" else "Record"
        pauseButton.text = if (c.player.state == MacroPlayer.State.PAUSED) "Resume" else "Pause"
        pad.hint = if (c.recorder.isRecording) "REC: tap here" else "Test pad"
    }

    private fun render() {
        dynamic.removeAllViews()

        dynamic.addView(sectionLabel(context, "Saved macros"))
        val saved = c.repository.list()
        if (saved.isEmpty()) dynamic.addView(bodyText(context, "No saved macros yet.", muted = true))
        saved.forEach { dynamic.addView(savedCard(it)) }

        dynamic.addView(sectionLabel(context, "Editor"))
        dynamic.addView(smallButton(context, "Insert tap") { insertTap() }.apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = context.dp(8) }
        })
        if (c.events.isEmpty()) dynamic.addView(bodyText(context, "No events.", muted = true))
        c.events.take(MAX_ROWS).forEachIndexed { i, e -> dynamic.addView(eventRow(i, e)) }
        if (c.events.size > MAX_ROWS) {
            dynamic.addView(bodyText(context, "Showing first $MAX_ROWS of ${c.events.size} events.", muted = true))
        }
        refreshStatus()
    }

    private fun savedCard(m: Macro): View = card(context).apply {
        addView(bodyText(context, "${m.name} · ${m.events.size} events"))
        addView(
            row(
                context,
                smallButton(context, "Load") { load(m) },
                smallButton(context, "Rename") { rename(m) },
                smallButton(context, "Copy") { duplicate(m) },
                smallButton(context, "Delete") { delete(m) }
            ).apply { setPadding(0, context.dp(8), 0, 0) }
        )
    }

    private fun eventRow(index: Int, e: MacroEvent): View = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        addView(
            bodyText(
                context,
                String.format(Locale.US, "#%d %s  t=%dms  (%.2f, %.2f)", index + 1, e.type.name, e.timeMs, e.x, e.y)
            ).apply { layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) }
        )
        addView(smallButton(context, "Time") { editTime(index) })
        addView(smallButton(context, "Del") { deleteEvent(index) })
    }

    private companion object {
        const val MAX_ROWS = 60
    }
}
