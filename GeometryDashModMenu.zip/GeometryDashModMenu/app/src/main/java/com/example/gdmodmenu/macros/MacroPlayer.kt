package com.example.gdmodmenu.macros

import android.os.Handler

/** Plays a list of events on the given handler's thread (main thread in the app). */
class MacroPlayer(private val handler: Handler, private val clock: () -> Long) {

    enum class State { IDLE, PLAYING, PAUSED }

    var state: State = State.IDLE
        private set

    /** Playback speed multiplier (1.0 = real time). Read when playback starts or resumes. */
    var speed: Float = 1f

    var onEvent: ((MacroEvent) -> Unit)? = null
    var onProgress: ((Float) -> Unit)? = null
    var onFinished: (() -> Unit)? = null

    private var events: List<MacroEvent> = emptyList()
    private var index = 0
    private var resumedAt = 0L
    private var offsetMs = 0L

    private fun position(): Long = offsetMs + ((clock() - resumedAt) * speed).toLong()

    private val tick = object : Runnable {
        override fun run() {
            if (state != State.PLAYING) return
            val pos = position()
            while (index < events.size && events[index].timeMs <= pos) {
                onEvent?.invoke(events[index])
                index++
            }
            val total = events.lastOrNull()?.timeMs ?: 0L
            onProgress?.invoke(if (total <= 0L) 1f else (pos.toFloat() / total).coerceIn(0f, 1f))
            if (index >= events.size) {
                state = State.IDLE
                onFinished?.invoke()
            } else {
                handler.postDelayed(this, 8)
            }
        }
    }

    fun start(list: List<MacroEvent>) {
        stop()
        if (list.isEmpty()) return
        events = list
        index = 0
        offsetMs = 0L
        resumedAt = clock()
        state = State.PLAYING
        handler.post(tick)
    }

    fun pause() {
        if (state != State.PLAYING) return
        offsetMs = position()
        state = State.PAUSED
        handler.removeCallbacks(tick)
    }

    fun resume() {
        if (state != State.PAUSED) return
        resumedAt = clock()
        state = State.PLAYING
        handler.post(tick)
    }

    fun stop() {
        handler.removeCallbacks(tick)
        state = State.IDLE
        index = 0
        offsetMs = 0L
    }
}
