package com.example.gdmodmenu.gamelink

import java.net.InetSocketAddress
import java.net.Socket

/**
 * Talks to the payload running inside a patched Geometry Dash (loopback TCP, 127.0.0.1:38999).
 * Blocking: never call from the main thread.
 */
object GameLink {
    const val HOST = "127.0.0.1"
    const val PORT = 38999

    data class Result(val ok: Boolean, val text: String)

    fun send(command: String, timeoutMs: Int = 3000): Result = sendBlock(command, emptyList(), timeoutMs)

    /** Sends [first] followed by [lines] (e.g. "MACRO SET n" + n event lines) and returns the reply. */
    fun sendBlock(first: String, lines: List<String>, timeoutMs: Int = 8000): Result = try {
        Socket().use { socket ->
            socket.connect(InetSocketAddress(HOST, PORT), 2000)
            socket.soTimeout = timeoutMs
            val text = StringBuilder(first).append('\n')
            lines.forEach { text.append(it).append('\n') }
            socket.getOutputStream().apply {
                write(text.toString().toByteArray())
                flush()
            }
            Result(true, socket.getInputStream().bufferedReader().readText().trim())
        }
    } catch (e: Exception) {
        Result(false, e.message ?: e.javaClass.simpleName)
    }
}
