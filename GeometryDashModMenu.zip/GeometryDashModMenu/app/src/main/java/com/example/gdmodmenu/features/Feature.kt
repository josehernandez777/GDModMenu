package com.example.gdmodmenu.features

/** Top-level sections of the menu, in display order. */
enum class Category(val title: String) {
    PLAYER("PLAYER"),
    VISUAL("VISUAL"),
    GAMEPLAY("GAMEPLAY"),
    MACROS("MACROS"),
    CONFIGURATION("CONFIGURATION"),
    GAME_LINK("GAME LINK"),
    ABOUT("ABOUT")
}

/** Honest availability of a feature. Nothing is ever reported as AVAILABLE unless it really works. */
enum class Availability {
    /** Self-contained feature of this app that is scheduled for a later milestone. */
    PLANNED,

    /** Needs access to the Geometry Dash process; blocked until a legitimate mechanism is found (Milestone 5). */
    REQUIRES_INTEGRATION,

    /** Implemented and functional. */
    AVAILABLE
}

/** Result of an availability check: state plus a human-readable reason. */
data class FeatureStatus(val availability: Availability, val reason: String)

/**
 * Contract every modular feature implements.
 * Milestone 1 only defines identity + availability; enable/configure hooks arrive with Milestone 4.
 */
interface ModFeature {
    val id: String
    val name: String
    val description: String
    val category: Category
    fun checkAvailability(): FeatureStatus
}

/** Placeholder feature that reports its true (not yet implemented) status. */
class PlannedFeature(
    override val id: String,
    override val name: String,
    override val description: String,
    override val category: Category,
    private val availability: Availability,
    private val note: String
) : ModFeature {
    init {
        require(availability != Availability.AVAILABLE) { "PlannedFeature cannot be AVAILABLE" }
    }

    override fun checkAvailability(): FeatureStatus = FeatureStatus(availability, note)
}

/** A feature that is really implemented. [note] tells where to use it. */
class ImplementedFeature(
    override val id: String,
    override val name: String,
    override val description: String,
    override val category: Category,
    private val note: String
) : ModFeature {
    override fun checkAvailability(): FeatureStatus = FeatureStatus(Availability.AVAILABLE, note)
}
