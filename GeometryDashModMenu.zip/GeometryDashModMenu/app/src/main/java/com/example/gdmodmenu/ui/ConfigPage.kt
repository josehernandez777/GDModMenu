package com.example.gdmodmenu.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import com.example.gdmodmenu.settings.SettingDefaults
import com.example.gdmodmenu.settings.SettingsModel
import com.example.gdmodmenu.settings.SettingsStore

/** Configuration page: persistent settings, profiles, reset, export/import (clipboard). */
class ConfigPage(private val context: Context) {

    private val body = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }

    private val model get() = SettingsStore.model

    fun addTo(column: LinearLayout) {
        column.addView(body)
        render()
    }

    private fun render() {
        body.removeAllViews()

        body.addView(sectionLabel(context, "Profiles"))
        model.profileNames().forEach { body.addView(profileCard(it)) }
        body.addView(smallButton(context, "New profile (copy of active)") {
            promptText(context, "New profile name", "", false) { n ->
                if (model.createProfile(n)) {
                    SettingsStore.save()
                    applyKeepScreenOn(context)
                    render()
                } else {
                    toast(context, "Invalid or duplicate name")
                }
            }
        })

        body.addView(sectionLabel(context, "Settings (profile: ${model.active})"))
        body.addView(card(context).apply {
            addView(
                switchRow(context, "Page animations", "Slide/fade when changing section.",
                    model.getBool(SettingDefaults.ANIMATIONS)) { v ->
                    model.set(SettingDefaults.ANIMATIONS, v.toString())
                    SettingsStore.save()
                }
            )
            addView(
                switchRow(context, "Keep screen on", "Prevents the screen from sleeping while the app is open.",
                    model.getBool(SettingDefaults.KEEP_SCREEN_ON)) { v ->
                    model.set(SettingDefaults.KEEP_SCREEN_ON, v.toString())
                    SettingsStore.save()
                    applyKeepScreenOn(context)
                }
            )
            addView(numberRow("Default tap duration (ms)", "Used by 'Insert tap' in the macro editor.", SettingDefaults.TAP_MS))
            addView(numberRow("Playback speed (%)", "Speed of macro playback in the test pad.", SettingDefaults.PLAYBACK_SPEED))
        })

        body.addView(sectionLabel(context, "Backup"))
        body.addView(
            row(
                context,
                smallButton(context, "Reset profile") {
                    model.resetActive()
                    SettingsStore.save()
                    applyKeepScreenOn(context)
                    toast(context, "Profile reset to defaults")
                    render()
                },
                smallButton(context, "Export") { exportToClipboard() },
                smallButton(context, "Import") { importFromClipboard() }
            )
        )
        body.addView(
            bodyText(
                context,
                "Export copies all profiles as JSON to the clipboard; Import reads JSON from the clipboard " +
                    "(validated, profiles with the same name are overwritten). Settings format v${SettingsModel.FORMAT_VERSION}.",
                muted = true
            )
        )
    }

    private fun profileCard(name: String): View = card(context).apply {
        val active = name == model.active
        addView(bodyText(context, if (active) "$name  (active)" else name))
        addView(
            row(
                context,
                smallButton(context, "Use") {
                    model.switchTo(name)
                    SettingsStore.save()
                    applyKeepScreenOn(context)
                    render()
                },
                smallButton(context, "Delete") {
                    if (model.deleteProfile(name)) {
                        SettingsStore.save()
                        applyKeepScreenOn(context)
                        render()
                    } else {
                        toast(context, "The last profile cannot be deleted")
                    }
                }
            ).apply { setPadding(0, context.dp(8), 0, 0) }
        )
    }

    private fun numberRow(title: String, description: String, key: String): View {
        val range = SettingDefaults.intRanges.getValue(key)
        return LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, context.dp(6), 0, context.dp(6))
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                addView(bodyText(context, "$title: ${model.getInt(key)}"))
                addView(bodyText(context, description, muted = true))
            })
            addView(smallButton(context, "Change") {
                promptText(context, "$title (${range.first}-${range.last})", model.getInt(key).toString(), true) { s ->
                    val v = s.toIntOrNull()
                    if (v == null || v !in range) {
                        toast(context, "Enter a number from ${range.first} to ${range.last}")
                    } else {
                        model.set(key, v.toString())
                        SettingsStore.save()
                        render()
                    }
                }
            })
        }
    }

    private fun exportToClipboard() {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("gdmodmenu-config", model.toJson()))
        toast(context, "Configuration copied to clipboard")
    }

    private fun importFromClipboard() {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip
        val text = if (clip != null && clip.itemCount > 0) clip.getItemAt(0).text?.toString() else null
        if (text.isNullOrBlank()) {
            toast(context, "Clipboard is empty")
            return
        }
        try {
            val other = SettingsModel.fromJson(text)
            model.importFrom(other)
            SettingsStore.save()
            applyKeepScreenOn(context)
            toast(context, "Imported ${other.profileNames().size} profile(s)")
            render()
        } catch (e: SettingsModel.InvalidSettingsException) {
            toast(context, e.message ?: "Invalid configuration")
        }
    }
}
