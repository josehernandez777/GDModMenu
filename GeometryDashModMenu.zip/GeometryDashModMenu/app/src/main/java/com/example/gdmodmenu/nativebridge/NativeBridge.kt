package com.example.gdmodmenu.nativebridge

/**
 * Kotlin <-> C++ bridge (JNI). Loads libgdmodmenu.so, built from app/src/main/cpp.
 * All calls are safe to make even if the library failed to load: they return fallbacks.
 */
object NativeBridge {

    /** True if System.loadLibrary succeeded. */
    val isLoaded: Boolean = try {
        System.loadLibrary("gdmodmenu")
        true
    } catch (e: UnsatisfiedLinkError) {
        false
    }

    /** Native library version string, or "unavailable". */
    fun version(): String = if (isLoaded) nativeVersion() else "unavailable"

    /** ABI the native library was compiled for, or "unavailable". */
    fun abi(): String = if (isLoaded) nativeAbi() else "unavailable"

    /** Round-trip test through JNI. Returns true when native result matches the Kotlin expectation. */
    fun selfTest(): Boolean {
        if (!isLoaded) return false
        val input = 21
        return nativeSelfTest(input) == expectedSelfTest(input)
    }

    /** Must mirror gdmm::core::selfTest in native_info.cpp. */
    internal fun expectedSelfTest(x: Int): Int = x * 2 + 1

    private external fun nativeVersion(): String
    private external fun nativeAbi(): String
    private external fun nativeSelfTest(x: Int): Int
}
