package com.example.gdmodmenu.settings

import org.json.JSONException
import org.json.JSONObject

/** Known settings, defaults and validation. */
object SettingDefaults {
    const val ANIMATIONS = "ui.animations"
    const val KEEP_SCREEN_ON = "ui.keep_screen_on"
    const val TAP_MS = "macro.default_tap_ms"
    const val PLAYBACK_SPEED = "macro.playback_speed_percent"

    val values: Map<String, String> = mapOf(
        ANIMATIONS to "true",
        KEEP_SCREEN_ON to "false",
        TAP_MS to "80",
        PLAYBACK_SPEED to "100"
    )

    val intRanges: Map<String, IntRange> = mapOf(
        TAP_MS to 10..2000,
        PLAYBACK_SPEED to 25..400
    )

    fun isValid(key: String, value: String): Boolean = when {
        key !in values -> false
        key in intRanges -> value.toIntOrNull()?.let { it in intRanges.getValue(key) } ?: false
        else -> value == "true" || value == "false"
    }
}

/** Profiles of settings. Pure Kotlin + org.json (persistence lives in SettingsStore). */
class SettingsModel private constructor(
    private val profiles: LinkedHashMap<String, MutableMap<String, String>>,
    active: String
) {
    class InvalidSettingsException(message: String) : Exception(message)

    var active: String = active
        private set

    fun profileNames(): List<String> = profiles.keys.toList()

    private fun current(): MutableMap<String, String> = profiles.getValue(active)

    fun getString(key: String): String = current()[key] ?: SettingDefaults.values.getValue(key)
    fun getBool(key: String): Boolean = getString(key) == "true"
    fun getInt(key: String): Int =
        getString(key).toIntOrNull() ?: SettingDefaults.values.getValue(key).toInt()

    fun set(key: String, value: String) {
        require(SettingDefaults.isValid(key, value)) { "invalid value for $key" }
        current()[key] = value
    }

    /** Creates a profile copying the active one. Returns false for blank/duplicate/too long names. */
    fun createProfile(name: String): Boolean {
        val n = name.trim()
        if (n.isEmpty() || n.length > 40 || n in profiles) return false
        profiles[n] = current().toMutableMap()
        active = n
        return true
    }

    fun switchTo(name: String): Boolean {
        if (name !in profiles) return false
        active = name
        return true
    }

    /** The last remaining profile cannot be deleted. */
    fun deleteProfile(name: String): Boolean {
        if (profiles.size <= 1 || name !in profiles) return false
        profiles.remove(name)
        if (active == name) active = profiles.keys.first()
        return true
    }

    fun resetActive() {
        current().clear()
    }

    /** Adds/overwrites profiles from [other]; keeps the current active profile. */
    fun importFrom(other: SettingsModel) {
        other.profiles.forEach { (n, v) -> profiles[n] = v.toMutableMap() }
    }

    fun toJson(): String {
        val ps = JSONObject()
        profiles.forEach { (name, vals) ->
            val o = JSONObject()
            vals.forEach { (k, v) -> o.put(k, v) }
            ps.put(name, o)
        }
        return JSONObject()
            .put("formatVersion", FORMAT_VERSION)
            .put("active", active)
            .put("profiles", ps)
            .toString(2)
    }

    companion object {
        const val FORMAT_VERSION = 1
        const val DEFAULT_PROFILE = "Default"

        fun default(): SettingsModel {
            val map = LinkedHashMap<String, MutableMap<String, String>>()
            map[DEFAULT_PROFILE] = mutableMapOf()
            return SettingsModel(map, DEFAULT_PROFILE)
        }

        fun fromJson(text: String): SettingsModel {
            try {
                val o = JSONObject(text)
                if (o.getInt("formatVersion") != FORMAT_VERSION) {
                    throw InvalidSettingsException("Unsupported format version")
                }
                val ps = o.getJSONObject("profiles")
                if (ps.length() == 0) throw InvalidSettingsException("No profiles")
                val map = LinkedHashMap<String, MutableMap<String, String>>()
                val names = ps.keys()
                while (names.hasNext()) {
                    val name = names.next()
                    if (name.isBlank() || name.length > 40) throw InvalidSettingsException("Invalid profile name")
                    val po = ps.getJSONObject(name)
                    val vals = mutableMapOf<String, String>()
                    val keys = po.keys()
                    while (keys.hasNext()) {
                        val k = keys.next()
                        val v = po.getString(k)
                        if (k !in SettingDefaults.values) continue // unknown keys are ignored (forward compatible)
                        if (!SettingDefaults.isValid(k, v)) throw InvalidSettingsException("Invalid value for $k")
                        vals[k] = v
                    }
                    map[name] = vals
                }
                val active = o.getString("active")
                if (active !in map) throw InvalidSettingsException("Active profile does not exist")
                return SettingsModel(map, active)
            } catch (e: JSONException) {
                throw InvalidSettingsException("Invalid settings: ${e.message}")
            }
        }
    }
}
