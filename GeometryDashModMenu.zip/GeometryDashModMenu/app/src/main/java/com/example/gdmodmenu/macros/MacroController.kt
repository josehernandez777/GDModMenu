package com.example.gdmodmenu.macros

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.io.File

/** Process-wide macro state, so it survives switching between menu pages. Main thread only. */
object MacroController {
    private val clock: () -> Long = { SystemClock.uptimeMillis() }

    val recorder = MacroRecorder(clock)
    val player = MacroPlayer(Handler(Looper.getMainLooper()), clock)

    private var repo: MacroRepository? = null
    val repository: MacroRepository
        get() = repo ?: error("MacroController.init(context) was not called")

    /** Id of the saved macro being edited, or null when it has not been saved yet. */
    var currentId: String? = null
    var currentName: String = "New macro"
    var events: List<MacroEvent> = emptyList()

    /** The page that currently owns the player callbacks. */
    var owner: Any? = null

    fun init(context: Context) {
        if (repo == null) repo = MacroRepository(File(context.filesDir, "macros"))
    }

    fun newMacro() {
        player.stop()
        currentId = null
        currentName = "New macro"
        events = emptyList()
    }
}
