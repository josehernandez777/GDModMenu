package com.example.gdmodmenu.macros

import java.io.File
import java.util.UUID

/** Stores each macro as <id>.json inside [dir]. Pure java.io so it can be unit-tested. */
class MacroRepository(private val dir: File) {

    init {
        dir.mkdirs()
    }

    private fun fileFor(id: String): File {
        require(MACRO_ID_REGEX.matches(id)) { "invalid macro id" }
        return File(dir, "$id.json")
    }

    fun list(): List<Macro> =
        (dir.listFiles { f -> f.isFile && f.extension == "json" } ?: emptyArray())
            .mapNotNull { f ->
                try {
                    MacroJson.fromJson(f.readText())
                } catch (e: Exception) {
                    null // corrupt files are skipped, never crash the UI
                }
            }
            .sortedBy { it.createdAt }

    fun load(id: String): Macro? = try {
        val f = fileFor(id)
        if (f.exists()) MacroJson.fromJson(f.readText()) else null
    } catch (e: Exception) {
        null
    }

    fun save(macro: Macro) {
        val target = fileFor(macro.id)
        val tmp = File(dir, "${macro.id}.json.tmp")
        tmp.writeText(MacroJson.toJson(macro))
        if (!tmp.renameTo(target)) {
            target.writeText(MacroJson.toJson(macro))
            tmp.delete()
        }
    }

    fun delete(id: String): Boolean = fileFor(id).delete()

    fun rename(id: String, newName: String): Macro? {
        val name = newName.trim()
        if (name.isEmpty()) return null
        val renamed = load(id)?.copy(name = name) ?: return null
        save(renamed)
        return renamed
    }

    fun duplicate(id: String): Macro? {
        val original = load(id) ?: return null
        val copy = original.copy(
            id = UUID.randomUUID().toString(),
            name = original.name + " copy",
            createdAt = System.currentTimeMillis()
        )
        save(copy)
        return copy
    }
}
