package com.example.gdmodmenu

import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.example.gdmodmenu.features.Category
import com.example.gdmodmenu.macros.MacroController
import com.example.gdmodmenu.settings.SettingDefaults
import com.example.gdmodmenu.settings.SettingsStore
import com.example.gdmodmenu.ui.applyKeepScreenOn
import com.example.gdmodmenu.ui.PageFactory
import com.example.gdmodmenu.ui.dp

/** Single-activity, fullscreen landscape UI with a left navigation rail. */
class MainActivity : AppCompatActivity() {

    private lateinit var navContainer: LinearLayout
    private lateinit var contentContainer: FrameLayout
    private val categories = Category.values().toList()
    private var selectedIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val attrs = window.attributes
            attrs.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = attrs
        }
        setContentView(R.layout.activity_main)
        SettingsStore.init(this)
        MacroController.init(this)
        applyKeepScreenOn(this)

        navContainer = findViewById(R.id.navContainer)
        contentContainer = findViewById(R.id.contentContainer)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.root)) { view, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        selectedIndex = savedInstanceState?.getInt(KEY_SELECTED, 0) ?: 0
        if (selectedIndex !in categories.indices) selectedIndex = 0

        buildNav()
        select(selectedIndex, animate = false)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt(KEY_SELECTED, selectedIndex)
    }

    private fun hideSystemBars() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
    }

    private fun buildNav() {
        categories.forEachIndexed { index, category ->
            val item = TextView(this).apply {
                text = category.title
                textSize = 14f
                setTypeface(typeface, Typeface.BOLD)
                letterSpacing = 0.08f
                setPadding(dp(14), dp(12), dp(14), dp(12))
                isClickable = true
                isFocusable = true
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(6) }
                setOnClickListener { select(index, animate = true) }
            }
            navContainer.addView(item)
        }
    }

    private fun select(index: Int, animate: Boolean) {
        selectedIndex = index

        for (i in 0 until navContainer.childCount) {
            val item = navContainer.getChildAt(i) as TextView
            val selected = i == index
            item.background = if (selected) ContextCompat.getDrawable(this, R.drawable.bg_nav_selected) else null
            item.setTextColor(ContextCompat.getColor(this, if (selected) R.color.gd_text else R.color.gd_muted))
        }

        contentContainer.removeAllViews()
        val page = PageFactory.build(this, categories[index])
        contentContainer.addView(page)
        if (animate && SettingsStore.model.getBool(SettingDefaults.ANIMATIONS)) {
            page.alpha = 0f
            page.translationX = dp(24).toFloat()
            page.animate().alpha(1f).translationX(0f).setDuration(220).start()
        }
    }

    private companion object {
        const val KEY_SELECTED = "selected_index"
    }
}
