package com.example.gdmodmenu.macros

enum class EventType { DOWN, UP }

/** One input event. [x] and [y] are normalized (0..1) inside the test pad; [timeMs] is relative to the macro start. */
data class MacroEvent(val timeMs: Long, val type: EventType, val x: Float, val y: Float)

data class Macro(
    val id: String,
    val name: String,
    val createdAt: Long,
    val events: List<MacroEvent>,
    val formatVersion: Int = CURRENT_FORMAT
) {
    companion object {
        const val CURRENT_FORMAT = 1
    }
}

/** Ids are used as file names, so only a safe charset is accepted. */
internal val MACRO_ID_REGEX = Regex("[A-Za-z0-9-]{1,64}")
