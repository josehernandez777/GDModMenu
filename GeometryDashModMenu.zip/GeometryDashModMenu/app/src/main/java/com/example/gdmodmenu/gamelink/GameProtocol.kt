package com.example.gdmodmenu.gamelink

import com.example.gdmodmenu.macros.EventType
import com.example.gdmodmenu.macros.MacroEvent

/**
 * Text format shared with the payload (see game.cpp):
 *   reply of MACRO GET:  "events N" then N lines "timeMs,D|U,button,player2(0/1)"
 *   request MACRO SET N: the same N lines follow the command line.
 * Pure Kotlin, unit-tested.
 */
object GameProtocol {

    fun formatEvents(events: List<MacroEvent>): List<String> = events.map { e ->
        "${e.timeMs},${if (e.type == EventType.DOWN) "D" else "U"},${e.button},${if (e.player2) 1 else 0}"
    }

    /** @throws IllegalArgumentException when the reply is malformed. */
    fun parseEvents(text: String): List<MacroEvent> {
        val lines = text.lines().map { it.trim() }.filter { it.isNotEmpty() }
        require(lines.isNotEmpty() && lines[0].startsWith("events ")) { "unexpected reply" }
        val count = lines[0].removePrefix("events ").toIntOrNull() ?: throw IllegalArgumentException("bad event count")
        val events = lines.drop(1).map { line ->
            val p = line.split(",")
            require(p.size == 4) { "bad event line: $line" }
            val type = when (p[1]) {
                "D" -> EventType.DOWN
                "U" -> EventType.UP
                else -> throw IllegalArgumentException("bad event type: ${p[1]}")
            }
            val time = p[0].toLongOrNull() ?: throw IllegalArgumentException("bad time: ${p[0]}")
            val button = p[2].toIntOrNull() ?: throw IllegalArgumentException("bad button: ${p[2]}")
            require(time >= 0 && button in 1..3) { "event out of range: $line" }
            MacroEvent(time, type, 0.5f, 0.5f, button, p[3] == "1")
        }
        require(events.size == count) { "event count mismatch" }
        require(events.zipWithNext().all { (a, b) -> a.timeMs <= b.timeMs }) { "events are not sorted" }
        return events
    }
}
