package com.example.gdmodmenu.features

/** Central list of all known features. Pure Kotlin (no Android deps) so it is unit-testable. */
object FeatureRegistry {

    private const val NEEDS_PROCESS =
        "Requires access to the game process. Not possible on Android 10 without root/injection; see docs/COMPATIBILITY.md."

    val all: List<ModFeature> = listOf(
        PlannedFeature(
            "player.profiles", "Preference profiles",
            "Save and switch between sets of preferences.",
            Category.PLAYER, Availability.PLANNED, "Milestone 2 (own app, no game access needed)."
        ),
        PlannedFeature(
            "player.controls", "Control options",
            "Compatible control options for the companion app.",
            Category.PLAYER, Availability.PLANNED, "Milestone 2."
        ),
        PlannedFeature(
            "visual.fps_counter", "FPS Counter",
            "Show frames per second.",
            Category.VISUAL, Availability.REQUIRES_INTEGRATION, NEEDS_PROCESS
        ),
        PlannedFeature(
            "visual.hitbox_viewer", "Hitbox Viewer",
            "Draw hitboxes of game objects.",
            Category.VISUAL, Availability.REQUIRES_INTEGRATION, NEEDS_PROCESS
        ),
        PlannedFeature(
            "visual.indicators", "Visual indicators",
            "On-screen indicators and display options.",
            Category.VISUAL, Availability.PLANNED, "Milestone 2 (for the app's own test environment)."
        ),
        PlannedFeature(
            "gameplay.practice_music", "Practice Music",
            "Play level music while practicing.",
            Category.GAMEPLAY, Availability.REQUIRES_INTEGRATION, NEEDS_PROCESS
        ),
        PlannedFeature(
            "gameplay.speed", "Speed configuration",
            "Adjust game speed.",
            Category.GAMEPLAY, Availability.REQUIRES_INTEGRATION, NEEDS_PROCESS
        ),
        PlannedFeature(
            "gameplay.practice_options", "Practice options",
            "Training preferences.",
            Category.GAMEPLAY, Availability.PLANNED, "Milestone 2 (preferences only)."
        )
    )

    fun byCategory(category: Category): List<ModFeature> = all.filter { it.category == category }
}
