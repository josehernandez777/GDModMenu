package com.example.gdmodmenu.features

/** Central list of all known features. Pure Kotlin (no Android deps) so it is unit-testable. */
object FeatureRegistry {

    private const val NEEDS_PROCESS =
        "Requires access to the game process. Not possible on Android 10 without root/injection; see docs/COMPATIBILITY.md."

    val all: List<ModFeature> = listOf(
        ImplementedFeature(
            "player.profiles", "Preference profiles",
            "Save and switch between sets of preferences.",
            Category.PLAYER, "Works now. Manage profiles in CONFIGURATION."
        ),
        ImplementedFeature(
            "player.controls", "Macro control options",
            "Tap duration and playback speed for macros.",
            Category.PLAYER, "Works now in the macro test pad. Change them in CONFIGURATION."
        ),
        PlannedFeature(
            "visual.fps_counter", "FPS Counter",
            "Show frames per second.",
            Category.VISUAL, Availability.REQUIRES_INTEGRATION, NEEDS_PROCESS
        ),
        PlannedFeature(
            "visual.hitbox_viewer", "Hitbox Viewer",
            "Draw hitboxes of game objects.",
            Category.VISUAL, Availability.REQUIRES_INTEGRATION, NEEDS_PROCESS
        ),
        ImplementedFeature(
            "visual.indicators", "Display options",
            "App display options: page animations and keep screen on.",
            Category.VISUAL, "Works now. Change them in CONFIGURATION."
        ),
        PlannedFeature(
            "gameplay.practice_music", "Practice Music",
            "Play level music while practicing.",
            Category.GAMEPLAY, Availability.REQUIRES_INTEGRATION, NEEDS_PROCESS
        ),
        PlannedFeature(
            "gameplay.speed", "Speed configuration",
            "Adjust game speed.",
            Category.GAMEPLAY, Availability.REQUIRES_INTEGRATION, NEEDS_PROCESS
        ),
        PlannedFeature(
            "gameplay.practice_options", "Practice options",
            "Training preferences.",
            Category.GAMEPLAY, Availability.PLANNED, "Milestone 2 (preferences only)."
        )
    )

    fun byCategory(category: Category): List<ModFeature> = all.filter { it.category == category }
}
