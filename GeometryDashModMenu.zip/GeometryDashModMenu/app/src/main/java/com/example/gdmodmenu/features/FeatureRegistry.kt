package com.example.gdmodmenu.features

/**
 * Central list of features shown as cards in PLAYER / VISUAL / GAMEPLAY.
 * Only implemented features are listed. In-game functions (noclip, macros in game) are controlled
 * from the GAME LINK page, which shows their real state reported by the payload.
 * Pure Kotlin (no Android deps) so it is unit-testable.
 */
object FeatureRegistry {

    val all: List<ModFeature> = listOf(
        ImplementedFeature(
            "player.profiles", "Preference profiles",
            "Save and switch between sets of preferences.",
            Category.PLAYER, "Works now. Manage profiles in CONFIGURATION."
        ),
        ImplementedFeature(
            "player.controls", "Macro control options",
            "Tap duration and playback speed for macros.",
            Category.PLAYER, "Works now in the macro test pad. Change them in CONFIGURATION."
        ),
        ImplementedFeature(
            "visual.indicators", "Display options",
            "App display options: page animations and keep screen on.",
            Category.VISUAL, "Works now. Change them in CONFIGURATION."
        )
    )

    fun byCategory(category: Category): List<ModFeature> = all.filter { it.category == category }
}
