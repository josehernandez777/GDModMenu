package com.example.gdmodmenu.macros

import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

/** Versioned JSON format (formatVersion = 1) with validation on load. */
object MacroJson {

    class InvalidMacroException(message: String) : Exception(message)

    fun toJson(macro: Macro): String {
        val events = JSONArray()
        macro.events.forEach { e ->
            events.put(
                JSONObject()
                    .put("t", e.timeMs)
                    .put("type", e.type.name)
                    .put("x", e.x.toDouble())
                    .put("y", e.y.toDouble())
                    .put("b", e.button)
                    .put("p2", e.player2)
            )
        }
        return JSONObject()
            .put("formatVersion", macro.formatVersion)
            .put("id", macro.id)
            .put("name", macro.name)
            .put("createdAt", macro.createdAt)
            .put("events", events)
            .toString(2)
    }

    fun fromJson(text: String): Macro {
        try {
            val o = JSONObject(text)
            val version = o.getInt("formatVersion")
            if (version != Macro.CURRENT_FORMAT) throw InvalidMacroException("Unsupported format version $version")
            val id = o.getString("id")
            if (!MACRO_ID_REGEX.matches(id)) throw InvalidMacroException("Invalid macro id")
            val name = o.getString("name").trim()
            if (name.isEmpty()) throw InvalidMacroException("Macro name is empty")
            val createdAt = o.getLong("createdAt")
            val arr = o.getJSONArray("events")
            val events = ArrayList<MacroEvent>(arr.length())
            var last = 0L
            for (i in 0 until arr.length()) {
                val e = arr.getJSONObject(i)
                val t = e.getLong("t")
                if (t < 0 || t < last) throw InvalidMacroException("Event $i has an invalid time")
                val type = try {
                    EventType.valueOf(e.getString("type"))
                } catch (ex: IllegalArgumentException) {
                    throw InvalidMacroException("Event $i has an unknown type")
                }
                val x = e.getDouble("x").toFloat()
                val y = e.getDouble("y").toFloat()
                if (x !in 0f..1f || y !in 0f..1f) throw InvalidMacroException("Event $i is outside the pad")
                val button = e.optInt("b", 1)
                if (button !in 1..3) throw InvalidMacroException("Event $i has an invalid button")
                events.add(MacroEvent(t, type, x, y, button, e.optBoolean("p2", false)))
                last = t
            }
            return Macro(id, name, createdAt, events)
        } catch (e: JSONException) {
            throw InvalidMacroException("Invalid macro file: ${e.message}")
        }
    }
}
