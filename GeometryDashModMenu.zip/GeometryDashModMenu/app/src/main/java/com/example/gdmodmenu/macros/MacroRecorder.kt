package com.example.gdmodmenu.macros

/** Records events with times relative to start(). [clock] returns milliseconds (monotonic). */
class MacroRecorder(private val clock: () -> Long) {

    var isRecording: Boolean = false
        private set

    private var startMs = 0L
    private val events = mutableListOf<MacroEvent>()

    fun start() {
        events.clear()
        startMs = clock()
        isRecording = true
    }

    fun add(type: EventType, x: Float, y: Float) {
        if (!isRecording) return
        events.add(MacroEvent(clock() - startMs, type, x.coerceIn(0f, 1f), y.coerceIn(0f, 1f)))
    }

    fun stop(): List<MacroEvent> {
        isRecording = false
        return events.toList()
    }
}
