package com.example.gdmodmenu.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PointF
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import com.example.gdmodmenu.macros.EventType

/**
 * The macro test environment: a pad that reports touches (normalized 0..1) while recording
 * and visualizes taps during playback.
 */
class TestPadView(context: Context) : View(context) {

    var onPadTouch: ((EventType, Float, Float) -> Unit)? = null

    var hint: String = "Test pad"
        set(value) {
            field = value
            invalidate()
        }

    private class Ripple(val x: Float, val y: Float, val start: Long)

    private val ripples = mutableListOf<Ripple>()
    private var held: PointF? = null

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#14121F") }
    private val gridPaint = Paint().apply {
        color = Color.parseColor("#2B2646")
        strokeWidth = 2f
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#8E89A8")
        textSize = 42f
        textAlign = Paint.Align.CENTER
    }
    private val ripplePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#8B5CF6")
        style = Paint.Style.STROKE
        strokeWidth = 6f
    }
    private val heldPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#8B5CF6") }

    /** Shows a tap at normalized coordinates (used for live touches and playback). */
    fun showTap(nx: Float, ny: Float, down: Boolean) {
        val px = nx * width
        val py = ny * height
        if (down) {
            held = PointF(px, py)
            ripples.add(Ripple(px, py, SystemClock.uptimeMillis()))
        } else {
            held = null
        }
        postInvalidateOnAnimation()
    }

    fun clearHeld() {
        held = null
        postInvalidateOnAnimation()
    }

    private fun norm(value: Float, size: Int): Float =
        if (size <= 0) 0f else (value / size).coerceIn(0f, 1f)

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val nx = norm(event.x, width)
                val ny = norm(event.y, height)
                showTap(nx, ny, true)
                onPadTouch?.invoke(EventType.DOWN, nx, ny)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val nx = norm(event.x, width)
                val ny = norm(event.y, height)
                showTap(nx, ny, false)
                onPadTouch?.invoke(EventType.UP, nx, ny)
            }
            else -> Unit
        }
        return true
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        canvas.drawRoundRect(0f, 0f, w, h, 24f, 24f, bgPaint)
        val step = w / 10f
        var x = step
        while (x < w) {
            canvas.drawLine(x, 0f, x, h, gridPaint)
            x += step
        }
        var y = step
        while (y < h) {
            canvas.drawLine(0f, y, w, y, gridPaint)
            y += step
        }
        canvas.drawText(hint, w / 2f, h / 2f, textPaint)

        val now = SystemClock.uptimeMillis()
        val iter = ripples.iterator()
        var animating = false
        while (iter.hasNext()) {
            val r = iter.next()
            val age = now - r.start
            if (age > RIPPLE_MS) {
                iter.remove()
                continue
            }
            val f = age.toFloat() / RIPPLE_MS
            ripplePaint.alpha = ((1f - f) * 180).toInt()
            canvas.drawCircle(r.x, r.y, 20f + f * 80f, ripplePaint)
            animating = true
        }
        held?.let { canvas.drawCircle(it.x, it.y, 28f, heldPaint) }
        if (animating) postInvalidateOnAnimation()
    }

    private companion object {
        const val RIPPLE_MS = 450L
    }
}
