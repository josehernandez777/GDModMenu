package com.example.gdmodmenu.ui

import android.content.Context
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.example.gdmodmenu.R
import com.example.gdmodmenu.features.Availability
import com.example.gdmodmenu.features.ModFeature
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch

/** Small view-building helpers shared by all pages. */

fun Context.dp(value: Int): Int = Math.round(value * resources.displayMetrics.density)

private fun Context.color(res: Int): Int = ContextCompat.getColor(this, res)

private fun matchWrap(context: Context, bottomMarginDp: Int = 0) =
    LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
        bottomMargin = context.dp(bottomMarginDp)
    }

fun pageTitle(context: Context, text: String): TextView = TextView(context).apply {
    this.text = text
    textSize = 26f
    setTypeface(typeface, Typeface.BOLD)
    setTextColor(context.color(R.color.gd_text))
    layoutParams = matchWrap(context, 16)
}

fun bodyText(context: Context, text: String, muted: Boolean = false): TextView = TextView(context).apply {
    this.text = text
    textSize = 13f
    setTextColor(context.color(if (muted) R.color.gd_muted else R.color.gd_text))
    setLineSpacing(0f, 1.15f)
}

/** Rounded dark card, vertical LinearLayout. */
fun card(context: Context): LinearLayout = LinearLayout(context).apply {
    orientation = LinearLayout.VERTICAL
    background = ContextCompat.getDrawable(context, R.drawable.bg_card)
    setPadding(context.dp(16), context.dp(14), context.dp(16), context.dp(14))
    layoutParams = matchWrap(context, 12)
}

fun infoCard(context: Context, title: String, body: String): View = card(context).apply {
    addView(TextView(context).apply {
        text = title
        textSize = 16f
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(context.color(R.color.gd_accent))
    })
    addView(bodyText(context, body).apply { setPadding(0, context.dp(6), 0, 0) })
}

fun keyValueRow(context: Context, key: String, value: String): View = LinearLayout(context).apply {
    orientation = LinearLayout.HORIZONTAL
    gravity = Gravity.CENTER_VERTICAL
    setPadding(0, context.dp(4), 0, context.dp(4))
    addView(bodyText(context, key, muted = true).apply {
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
    })
    addView(bodyText(context, value))
}

/** Card for one feature. The switch is disabled: nothing can be toggled until a feature is really implemented. */
fun featureCard(context: Context, feature: ModFeature): View {
    val status = feature.checkAvailability()
    val statusLabel = when (status.availability) {
        Availability.AVAILABLE -> "AVAILABLE"
        Availability.PLANNED -> "PLANNED"
        Availability.REQUIRES_INTEGRATION -> "BLOCKED: NEEDS GAME INTEGRATION"
    }
    val statusColor = when (status.availability) {
        Availability.AVAILABLE -> R.color.gd_ok
        else -> R.color.gd_warning
    }
    return card(context).apply {
        addView(LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(TextView(context).apply {
                text = feature.name
                textSize = 16f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(context.color(R.color.gd_text))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            if (status.availability != Availability.AVAILABLE) {
                addView(MaterialSwitch(context).apply {
                    isChecked = false
                    isEnabled = false // cannot be toggled until the feature really exists
                })
            }
        })
        addView(bodyText(context, feature.description, muted = true))
        addView(TextView(context).apply {
            text = statusLabel
            textSize = 11f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(context.color(statusColor))
            setPadding(0, context.dp(8), 0, 0)
        })
        addView(bodyText(context, status.reason, muted = true))
    }
}

fun actionButton(context: Context, label: String, onClick: () -> Unit): View = MaterialButton(context).apply {
    text = label
    isAllCaps = false
    setOnClickListener { onClick() }
    layoutParams = matchWrap(context, 12)
}
