package com.example.gdmodmenu.ui

import android.app.Activity
import android.content.Context
import android.graphics.Typeface
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import com.example.gdmodmenu.R
import com.example.gdmodmenu.settings.SettingDefaults
import com.example.gdmodmenu.settings.SettingsStore
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch

/** More view helpers (buttons, rows, dialogs) used by the Macros and Configuration pages. */

fun smallButton(context: Context, label: String, onClick: () -> Unit): MaterialButton =
    MaterialButton(context).apply {
        text = label
        isAllCaps = false
        textSize = 12f
        maxLines = 1
        setOnClickListener { onClick() }
    }

/** Horizontal row where every view gets the same width. */
fun row(context: Context, vararg views: View): LinearLayout = LinearLayout(context).apply {
    orientation = LinearLayout.HORIZONTAL
    layoutParams = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = context.dp(8) }
    views.forEachIndexed { i, v ->
        v.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            if (i > 0) marginStart = context.dp(6)
        }
        addView(v)
    }
}

fun sectionLabel(context: Context, text: String): TextView = TextView(context).apply {
    this.text = text
    textSize = 15f
    setTypeface(typeface, Typeface.BOLD)
    setTextColor(ContextCompat.getColor(context, R.color.gd_accent))
    setPadding(0, context.dp(10), 0, context.dp(8))
}

fun switchRow(
    context: Context,
    title: String,
    description: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit
): View = LinearLayout(context).apply {
    orientation = LinearLayout.HORIZONTAL
    gravity = Gravity.CENTER_VERTICAL
    setPadding(0, context.dp(6), 0, context.dp(6))
    addView(LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        addView(TextView(context).apply {
            text = title
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(ContextCompat.getColor(context, R.color.gd_text))
        })
        addView(bodyText(context, description, muted = true))
    })
    addView(MaterialSwitch(context).apply {
        isChecked = checked
        setOnCheckedChangeListener { _, value -> onChange(value) }
    })
}

fun toast(context: Context, message: String) {
    Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
}

fun promptText(context: Context, title: String, initial: String, numeric: Boolean, onOk: (String) -> Unit) {
    val input = EditText(context).apply {
        setText(initial)
        setSingleLine()
        if (numeric) inputType = InputType.TYPE_CLASS_NUMBER
        setSelection(text.length)
    }
    val holder = LinearLayout(context).apply {
        setPadding(context.dp(24), context.dp(8), context.dp(24), 0)
        addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }
    AlertDialog.Builder(context)
        .setTitle(title)
        .setView(holder)
        .setPositiveButton("OK") { _, _ -> onOk(input.text.toString()) }
        .setNegativeButton("Cancel", null)
        .show()
}

/** Applies the "keep screen on" setting to the activity window. */
fun applyKeepScreenOn(context: Context) {
    val window = (context as? Activity)?.window ?: return
    if (SettingsStore.model.getBool(SettingDefaults.KEEP_SCREEN_ON)) {
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    } else {
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }
}
