package com.example.gdmodmenu.ui

import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import com.example.gdmodmenu.features.Category
import com.example.gdmodmenu.features.FeatureRegistry
import com.example.gdmodmenu.gamelink.GameLink
import com.example.gdmodmenu.nativebridge.NativeBridge

/** Builds the content view for each category. */
object PageFactory {

    fun build(context: Context, category: Category): View {
        val scroll = ScrollView(context).apply {
            isVerticalScrollBarEnabled = false
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        val column = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(context.dp(24), context.dp(20), context.dp(24), context.dp(20))
        }
        scroll.addView(column)
        column.addView(pageTitle(context, category.title))

        when (category) {
            Category.PLAYER, Category.VISUAL, Category.GAMEPLAY ->
                FeatureRegistry.byCategory(category).forEach { column.addView(featureCard(context, it)) }

            Category.MACROS -> column.addView(
                infoCard(
                    context, "Macro bot: Milestone 3",
                    "Recording, saving, editing and playback (JSON, versioned format) will first work " +
                        "inside this app's own test environment. Integration with Geometry Dash controls " +
                        "is researched separately in Milestone 5. Nothing is recorded yet."
                )
            )

            Category.CONFIGURATION -> column.addView(
                infoCard(
                    context, "Settings: Milestone 2",
                    "Persistent preferences, profiles, reset, and import/export of configuration " +
                        "will live here. Not implemented yet."
                )
            )

            Category.GAME_LINK -> buildGameLink(context, column)

            Category.ABOUT -> buildAbout(context, column)
        }
        return scroll
    }

    private fun buildGameLink(context: Context, column: LinearLayout) {
        val output = bodyText(context, "Not checked yet.")
        fun run(command: String) {
            output.text = "Sending $command ..."
            Thread {
                val r = GameLink.send(command)
                output.post {
                    output.text = if (r.ok) r.text else
                        "No connection: ${r.text}\nIs the PATCHED Geometry Dash running (split screen / pop-up)?"
                }
            }.start()
        }
        column.addView(
            infoCard(
                context, "Link to Geometry Dash",
                "Talks to the payload inside a patched copy of the game (127.0.0.1:38999). " +
                    "Open the patched game, put this app in split-screen or pop-up view, then check the connection. " +
                    "The payload currently only probes: it lists the game's real symbols for the next step."
            )
        )
        column.addView(actionButton(context, "Check connection") { run("STATUS") })
        column.addView(actionButton(context, "List symbols: PlayLayer") { run("SYMBOLS PlayLayer") })
        column.addView(actionButton(context, "List symbols: CCScheduler") { run("SYMBOLS CCScheduler") })
        column.addView(card(context).apply { addView(output) })
    }

    private fun buildAbout(context: Context, column: LinearLayout) {
        val versionName = try {
            context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "?"
        } catch (e: Exception) {
            "?"
        }

        column.addView(card(context).apply {
            addView(keyValueRow(context, "App version", versionName))
            addView(keyValueRow(context, "Target game", "Geometry Dash Android 2.2091"))
            addView(keyValueRow(context, "Native library loaded", if (NativeBridge.isLoaded) "yes" else "NO"))
            addView(keyValueRow(context, "Native version", NativeBridge.version()))
            addView(keyValueRow(context, "Native ABI", NativeBridge.abi()))
            addView(keyValueRow(context, "JNI self-test", if (NativeBridge.selfTest()) "passed" else "FAILED"))
        })
        column.addView(
            infoCard(
                context, "Current status: Milestone 1 (foundation)",
                "This app is independent: no Geode, no Mega Hack, no root. By itself it does not touch " +
                    "Geometry Dash. The optional tool tools/patch_gd_apk.sh adds a payload to YOUR OWN copy " +
                    "of the game APK. In-game features stay blocked until they are built on that game's real " +
                    "symbols (see docs/INJECTION.md)."
            )
        )
    }
}
