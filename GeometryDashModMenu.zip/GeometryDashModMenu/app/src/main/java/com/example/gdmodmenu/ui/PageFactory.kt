package com.example.gdmodmenu.ui

import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import com.example.gdmodmenu.features.Category
import com.example.gdmodmenu.features.FeatureRegistry
import com.example.gdmodmenu.nativebridge.NativeBridge

/** Builds the content view for each category. */
object PageFactory {

    fun build(context: Context, category: Category): View {
        val scroll = ScrollView(context).apply {
            isVerticalScrollBarEnabled = false
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        val column = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(context.dp(24), context.dp(20), context.dp(24), context.dp(20))
        }
        scroll.addView(column)
        column.addView(pageTitle(context, category.title))

        when (category) {
            Category.PLAYER, Category.VISUAL, Category.GAMEPLAY ->
                FeatureRegistry.byCategory(category).forEach { column.addView(featureCard(context, it)) }

            Category.MACROS -> column.addView(
                infoCard(
                    context, "Macro bot: Milestone 3",
                    "Recording, saving, editing and playback (JSON, versioned format) will first work " +
                        "inside this app's own test environment. Integration with Geometry Dash controls " +
                        "is researched separately in Milestone 5. Nothing is recorded yet."
                )
            )

            Category.CONFIGURATION -> column.addView(
                infoCard(
                    context, "Settings: Milestone 2",
                    "Persistent preferences, profiles, reset, and import/export of configuration " +
                        "will live here. Not implemented yet."
                )
            )

            Category.ABOUT -> buildAbout(context, column)
        }
        return scroll
    }

    private fun buildAbout(context: Context, column: LinearLayout) {
        val versionName = try {
            context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "?"
        } catch (e: Exception) {
            "?"
        }

        column.addView(card(context).apply {
            addView(keyValueRow(context, "App version", versionName))
            addView(keyValueRow(context, "Target game", "Geometry Dash Android 2.2091"))
            addView(keyValueRow(context, "Native library loaded", if (NativeBridge.isLoaded) "yes" else "NO"))
            addView(keyValueRow(context, "Native version", NativeBridge.version()))
            addView(keyValueRow(context, "Native ABI", NativeBridge.abi()))
            addView(keyValueRow(context, "JNI self-test", if (NativeBridge.selfTest()) "passed" else "FAILED"))
        })
        column.addView(
            infoCard(
                context, "Current status: Milestone 1 (foundation)",
                "This app is independent: no Geode, no Mega Hack, no root. It does NOT modify or " +
                    "inject into Geometry Dash. Features that need access to the game process are " +
                    "listed as blocked until a legitimate mechanism is confirmed " +
                    "(see docs/COMPATIBILITY.md)."
            )
        )
    }
}
