package com.example.gdmodmenu.ui

import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import com.example.gdmodmenu.features.Category
import com.example.gdmodmenu.features.FeatureRegistry
import com.example.gdmodmenu.gamelink.GameLink
import com.example.gdmodmenu.gamelink.GameProtocol
import com.example.gdmodmenu.macros.MacroController
import com.example.gdmodmenu.nativebridge.NativeBridge

/** Builds the content view for each category. */
object PageFactory {

    fun build(context: Context, category: Category): View {
        val scroll = ScrollView(context).apply {
            isVerticalScrollBarEnabled = false
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        val column = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(context.dp(24), context.dp(20), context.dp(24), context.dp(20))
        }
        scroll.addView(column)
        column.addView(pageTitle(context, category.title))

        when (category) {
            Category.PLAYER, Category.VISUAL, Category.GAMEPLAY -> {
                val features = FeatureRegistry.byCategory(category)
                if (features.isEmpty()) {
                    column.addView(
                        infoCard(
                            context, "Nothing to configure here",
                            "In-game functions (noclip, recording and playing macros inside Geometry Dash) " +
                                "are in GAME LINK, because they only exist in a patched game."
                        )
                    )
                }
                features.forEach { column.addView(featureCard(context, it)) }
            }

            Category.MACROS -> MacrosPage(context).addTo(column)

            Category.CONFIGURATION -> ConfigPage(context).addTo(column)

            Category.GAME_LINK -> buildGameLink(context, column)

            Category.ABOUT -> buildAbout(context, column)
        }
        return scroll
    }

    private fun buildGameLink(context: Context, column: LinearLayout) {
        val output = bodyText(context, "Not checked yet. Open the PATCHED game, then tap Status.")

        fun run(command: String, onOk: (String) -> Unit = {}) {
            output.text = "Sending $command ..."
            Thread {
                val r = GameLink.send(command)
                output.post {
                    if (r.ok) {
                        output.text = r.text
                        onOk(r.text)
                    } else {
                        output.text = "Not connected. This is normal unless the PATCHED Geometry Dash is open " +
                            "right now (a normal Play Store GD never answers).\nDetail: ${r.text}"
                    }
                }
            }.start()
        }

        column.addView(
            infoCard(
                context, "Link to Geometry Dash",
                "Controls the payload inside the patched game (127.0.0.1:38999). Hooks are installed at game " +
                    "start; Status shows exactly which game functions were hooked. For offline, local use only: " +
                    "do not use it for leaderboards or rated levels."
            )
        )
        column.addView(
            row(
                context,
                smallButton(context, "Status") { run("STATUS") },
                smallButton(context, "Install hooks") { run("HOOKS ON") }
            )
        )
        column.addView(
            row(
                context,
                smallButton(context, "Menu: install") { run("UI ON") },
                smallButton(context, "Menu: hide") { run("UI HIDE") },
                smallButton(context, "Menu: show") { run("UI SHOW") }
            )
        )
        column.addView(sectionLabel(context, "Noclip"))
        column.addView(
            row(
                context,
                smallButton(context, "Noclip ON") { run("NOCLIP ON") },
                smallButton(context, "Noclip OFF") { run("NOCLIP OFF") }
            )
        )
        column.addView(sectionLabel(context, "Speed, freeze and effects"))
        column.addView(
            row(
                context,
                smallButton(context, "Speed 0.5x") { run("SPEED 0.5") },
                smallButton(context, "Speed 1x") { run("SPEED 1") },
                smallButton(context, "Speed 2x") { run("SPEED 2") }
            )
        )
        column.addView(
            row(
                context,
                smallButton(context, "Freeze ON") { run("FREEZE ON") },
                smallButton(context, "Freeze OFF") { run("FREEZE OFF") },
                smallButton(context, "Step") { run("STEP") }
            )
        )
        column.addView(
            row(
                context,
                smallButton(context, "No shake ON") { run("NOSHAKE ON") },
                smallButton(context, "No shake OFF") { run("NOSHAKE OFF") }
            )
        )
        column.addView(
            row(
                context,
                smallButton(context, "No death fx ON") { run("NODEATHFX ON") },
                smallButton(context, "No death fx OFF") { run("NODEATHFX OFF") }
            )
        )
        column.addView(sectionLabel(context, "Macros in game"))
        column.addView(
            row(
                context,
                smallButton(context, "Record") { run("MACRO RECORD") },
                smallButton(context, "Stop") { run("MACRO STOP") }
            )
        )
        column.addView(
            row(
                context,
                smallButton(context, "Get recording") {
                    run("MACRO GET") { text ->
                        try {
                            val events = GameProtocol.parseEvents(text)
                            MacroController.currentId = null
                            MacroController.currentName = "Game recording"
                            MacroController.events = events
                            output.text = "Loaded ${events.size} events into MACROS (edit and save them there)."
                        } catch (e: IllegalArgumentException) {
                            output.text = "Could not read the recording: ${e.message}\n$text"
                        }
                    }
                },
                smallButton(context, "Send macro") {
                    val events = MacroController.events
                    if (events.isEmpty()) {
                        toast(context, "The MACROS editor has no events")
                    } else {
                        output.text = "Sending ${events.size} events ..."
                        Thread {
                            val r = GameLink.sendBlock("MACRO SET ${events.size}", GameProtocol.formatEvents(events))
                            output.post { output.text = if (r.ok) r.text else "Not connected: ${r.text}" }
                        }.start()
                    }
                }
            )
        )
        column.addView(
            row(
                context,
                smallButton(context, "Play in game") { run("MACRO PLAY") },
                smallButton(context, "Stop playing") { run("MACRO STOP") }
            )
        )
        column.addView(sectionLabel(context, "Diagnostics"))
        column.addView(
            row(
                context,
                smallButton(context, "Symbols: PlayLayer") { run("SYMBOLS PlayLayer") },
                smallButton(context, "Symbols: Button") { run("SYMBOLS Button") }
            )
        )
        column.addView(card(context).apply { addView(output) })
    }

    private fun buildAbout(context: Context, column: LinearLayout) {
        val versionName = try {
            context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "?"
        } catch (e: Exception) {
            "?"
        }

        column.addView(card(context).apply {
            addView(keyValueRow(context, "App version", versionName))
            addView(keyValueRow(context, "Target game", "Geometry Dash Android 2.2091"))
            addView(keyValueRow(context, "Native library loaded", if (NativeBridge.isLoaded) "yes" else "NO"))
            addView(keyValueRow(context, "Native version", NativeBridge.version()))
            addView(keyValueRow(context, "Native ABI", NativeBridge.abi()))
            addView(keyValueRow(context, "JNI self-test", if (NativeBridge.selfTest()) "passed" else "FAILED"))
        })
        column.addView(
            infoCard(
                context, "Current status: Milestone 1 (foundation)",
                "This app is independent: no Geode, no Mega Hack, no root. By itself it does not touch " +
                    "Geometry Dash. The optional tool tools/patch_gd_apk.sh adds a payload to YOUR OWN copy " +
                    "of the game APK. In-game features stay blocked until they are built on that game's real " +
                    "symbols (see docs/INJECTION.md)."
            )
        )
    }
}
