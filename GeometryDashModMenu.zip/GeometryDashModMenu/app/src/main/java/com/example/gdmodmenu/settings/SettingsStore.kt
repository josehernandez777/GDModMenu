package com.example.gdmodmenu.settings

import android.content.Context
import android.content.SharedPreferences

/** Persists the SettingsModel in SharedPreferences. Call init() once from MainActivity. */
object SettingsStore {
    private const val PREFS = "gdmm_settings"
    private const val KEY = "data"

    private var prefs: SharedPreferences? = null
    lateinit var model: SettingsModel
        private set

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs = p
        model = (try {
            p.getString(KEY, null)?.let { SettingsModel.fromJson(it) }
        } catch (e: Exception) {
            null
        }) ?: SettingsModel.default()
    }

    fun save() {
        prefs?.edit()?.putString(KEY, model.toJson())?.apply()
    }
}
