package com.example.gdmodmenu.features

import com.example.gdmodmenu.nativebridge.NativeBridge
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FeatureRegistryTest {

    @Test
    fun idsAreUnique() {
        val ids = FeatureRegistry.all.map { it.id }
        assertEquals(ids.size, ids.toSet().size)
    }

    @Test
    fun noFeatureClaimsToBeAvailableYet() {
        assertTrue(FeatureRegistry.all.none { it.checkAvailability().availability == Availability.AVAILABLE })
    }

    @Test
    fun everyFeatureHasTextAndReason() {
        FeatureRegistry.all.forEach {
            assertTrue(it.name.isNotBlank())
            assertTrue(it.description.isNotBlank())
            assertTrue(it.checkAvailability().reason.isNotBlank())
        }
    }

    @Test
    fun registryOnlyUsesFeatureCategories() {
        val allowed = setOf(Category.PLAYER, Category.VISUAL, Category.GAMEPLAY)
        assertTrue(FeatureRegistry.all.all { it.category in allowed })
        assertFalse(FeatureRegistry.byCategory(Category.VISUAL).isEmpty())
    }

    @Test
    fun selfTestFormulaMatchesNativeContract() {
        assertEquals(43, NativeBridge.expectedSelfTest(21))
    }
}
