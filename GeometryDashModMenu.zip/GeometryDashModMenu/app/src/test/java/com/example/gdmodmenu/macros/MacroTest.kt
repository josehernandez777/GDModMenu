package com.example.gdmodmenu.macros

import java.nio.file.Files
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MacroTest {

    private val events = listOf(
        MacroEvent(0, EventType.DOWN, 0.1f, 0.2f),
        MacroEvent(80, EventType.UP, 0.1f, 0.2f),
        MacroEvent(500, EventType.DOWN, 0.9f, 0.5f)
    )
    private val macro = Macro("abc-123", "Test", 1000L, events)

    @Test
    fun gameButtonsSurviveJson() {
        val m = macro.copy(events = listOf(MacroEvent(10, EventType.DOWN, 0.5f, 0.5f, 2, true)))
        val back = MacroJson.fromJson(MacroJson.toJson(m))
        assertEquals(2, back.events[0].button)
        assertTrue(back.events[0].player2)
    }

    @Test
    fun jsonRoundTrip() {
        val back = MacroJson.fromJson(MacroJson.toJson(macro))
        assertEquals(macro.id, back.id)
        assertEquals(macro.name, back.name)
        assertEquals(macro.events, back.events)
    }

    @Test(expected = MacroJson.InvalidMacroException::class)
    fun rejectsUnsortedTimes() {
        val bad = macro.copy(events = listOf(events[2], events[0]))
        MacroJson.fromJson(MacroJson.toJson(bad))
    }

    @Test(expected = MacroJson.InvalidMacroException::class)
    fun rejectsGarbage() {
        MacroJson.fromJson("not json")
    }

    @Test(expected = MacroJson.InvalidMacroException::class)
    fun rejectsUnknownVersion() {
        MacroJson.fromJson(MacroJson.toJson(macro).replace("\"formatVersion\": 1", "\"formatVersion\": 99"))
    }

    @Test
    fun editingKeepsEventsSorted() {
        val moved = MacroEditing.setTime(events, 0, 600)
        assertEquals(listOf(80L, 500L, 600L), moved.map { it.timeMs })
        assertEquals(2, MacroEditing.remove(events, 1).size)
        val inserted = MacroEditing.insertTap(events, 200, 0.5f, 0.5f, 50)
        assertEquals(5, inserted.size)
        assertEquals(inserted.map { it.timeMs }, inserted.map { it.timeMs }.sorted())
    }

    @Test
    fun recorderUsesRelativeTimes() {
        var now = 1000L
        val rec = MacroRecorder { now }
        rec.add(EventType.DOWN, 0.5f, 0.5f) // ignored: not recording
        rec.start()
        now = 1250L
        rec.add(EventType.DOWN, 2f, -1f) // coordinates are clamped
        val out = rec.stop()
        assertEquals(1, out.size)
        assertEquals(250L, out[0].timeMs)
        assertEquals(1f, out[0].x, 0f)
        assertEquals(0f, out[0].y, 0f)
    }

    @Test
    fun repositoryCrud() {
        val dir = Files.createTempDirectory("macros").toFile()
        val repo = MacroRepository(dir)
        repo.save(macro)
        assertEquals(1, repo.list().size)
        assertEquals("Renamed", repo.rename(macro.id, "Renamed")?.name)
        val copy = repo.duplicate(macro.id)
        assertNotNull(copy)
        assertNotEquals(macro.id, copy!!.id)
        assertEquals(2, repo.list().size)
        assertTrue(repo.delete(macro.id))
        assertNull(repo.load(macro.id))
        assertEquals(1, repo.list().size)
        dir.deleteRecursively()
    }
}
