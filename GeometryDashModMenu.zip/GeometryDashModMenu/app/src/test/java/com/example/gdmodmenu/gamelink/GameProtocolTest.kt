package com.example.gdmodmenu.gamelink

import com.example.gdmodmenu.macros.EventType
import com.example.gdmodmenu.macros.MacroEvent
import org.junit.Assert.assertEquals
import org.junit.Test

class GameProtocolTest {

    private val events = listOf(
        MacroEvent(0, EventType.DOWN, 0.5f, 0.5f, 1, false),
        MacroEvent(120, EventType.UP, 0.5f, 0.5f, 1, false),
        MacroEvent(900, EventType.DOWN, 0.5f, 0.5f, 1, true)
    )

    @Test
    fun formatMatchesPayloadFormat() {
        assertEquals(listOf("0,D,1,0", "120,U,1,0", "900,D,1,1"), GameProtocol.formatEvents(events))
    }

    @Test
    fun parseRoundTrip() {
        val reply = "events 3\n" + GameProtocol.formatEvents(events).joinToString("\n")
        assertEquals(events, GameProtocol.parseEvents(reply))
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsCountMismatch() {
        GameProtocol.parseEvents("events 2\n0,D,1,0")
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsBadType() {
        GameProtocol.parseEvents("events 1\n0,X,1,0")
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsErrorReply() {
        GameProtocol.parseEvents("ERR: needs hooks")
    }
}
