package com.example.gdmodmenu.settings

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SettingsModelTest {

    @Test
    fun defaultsAndOverrides() {
        val m = SettingsModel.default()
        assertEquals(80, m.getInt(SettingDefaults.TAP_MS))
        m.set(SettingDefaults.TAP_MS, "120")
        assertEquals(120, m.getInt(SettingDefaults.TAP_MS))
        m.resetActive()
        assertEquals(80, m.getInt(SettingDefaults.TAP_MS))
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsOutOfRangeValue() {
        SettingsModel.default().set(SettingDefaults.PLAYBACK_SPEED, "5000")
    }

    @Test
    fun profilesLifecycle() {
        val m = SettingsModel.default()
        m.set(SettingDefaults.PLAYBACK_SPEED, "150")
        assertTrue(m.createProfile("Fast"))
        assertEquals("Fast", m.active)
        assertEquals(150, m.getInt(SettingDefaults.PLAYBACK_SPEED)) // copied from the previous profile
        assertFalse(m.createProfile("Fast"))
        assertTrue(m.switchTo(SettingsModel.DEFAULT_PROFILE))
        assertTrue(m.deleteProfile("Fast"))
        assertFalse(m.deleteProfile(SettingsModel.DEFAULT_PROFILE)) // last profile stays
    }

    @Test
    fun exportImportRoundTrip() {
        val a = SettingsModel.default()
        a.set(SettingDefaults.ANIMATIONS, "false")
        a.createProfile("Other")
        val b = SettingsModel.fromJson(a.toJson())
        assertEquals(a.profileNames(), b.profileNames())
        assertEquals("Other", b.active)
        b.switchTo(SettingsModel.DEFAULT_PROFILE)
        assertFalse(b.getBool(SettingDefaults.ANIMATIONS))
    }

    @Test(expected = SettingsModel.InvalidSettingsException::class)
    fun importRejectsInvalidValues() {
        SettingsModel.fromJson(
            """{"formatVersion":1,"active":"Default","profiles":{"Default":{"macro.playback_speed_percent":"9999"}}}"""
        )
    }

    @Test(expected = SettingsModel.InvalidSettingsException::class)
    fun importRejectsGarbage() {
        SettingsModel.fromJson("hello")
    }
}
