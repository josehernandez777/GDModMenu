# Geometry Dash Mod Menu (independent)

Standalone Android app (Kotlin + C++17/JNI) with a fullscreen dark/purple UI.
No Geode, no Mega Hack, no root.

**Status: Milestone 1 (foundation).** Working: fullscreen UI with 6 categories, Kotlin<->C++ JNI bridge
(with self-test), feature registry, unit tests, CI that builds an APK.
**Not implemented yet** (shown honestly in the UI): macros, settings/profiles, any in-game feature.
This app does not modify or inject into Geometry Dash.

Build: see [docs/BUILD.md](docs/BUILD.md). Architecture: [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).
Integration limits: [docs/COMPATIBILITY.md](docs/COMPATIBILITY.md). Features: [docs/FEATURES.md](docs/FEATURES.md).
