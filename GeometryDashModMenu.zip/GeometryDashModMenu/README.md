# Geometry Dash Mod Menu (independent)

Standalone Android app (Kotlin + C++17/JNI) with a fullscreen dark/purple UI.
No Geode, no Mega Hack, no root.

**Status: in-game payload with hooks (untested on device), plus app.** Working: fullscreen UI with 6 categories, Kotlin<->C++ JNI bridge
(with self-test), feature registry, unit tests, CI that builds an APK.
**Not implemented yet**: macros, settings/profiles, in-game hooks. See docs/INJECTION.md for the patch tool.
The app itself does not touch the game; tools/patch_gd_apk.sh adds a payload to your own copy.

Build: see [docs/BUILD.md](docs/BUILD.md). Architecture: [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).
Integration limits: [docs/COMPATIBILITY.md](docs/COMPATIBILITY.md). Features: [docs/FEATURES.md](docs/FEATURES.md).
