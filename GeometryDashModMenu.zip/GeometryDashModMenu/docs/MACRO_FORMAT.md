# Macro formats

## App macros (JSON, `files/macros/<id>.json`)
```
{ "formatVersion": 1, "id": "<uuid>", "name": "...", "createdAt": <ms>,
  "events": [ { "t": <ms>, "type": "DOWN|UP", "x": 0..1, "y": 0..1, "b": 1..3, "p2": false } ] }
```
`x`/`y` are used by the test pad; `b` (button, 1 = jump) and `p2` (player 2) by the game. `b` and `p2` are optional
(defaults 1 / false), so older files still load. Times must be >= 0 and sorted.

## In-game slots (text, `Android/data/<game package>/files/macro_<n>.txt`)
```
GDMM-MACRO 1
<timeMs>,<D|U>,<button>,<p2 0|1>
```
Written by the in-game menu (Save) and read by Load. Same lines are used by the GAME LINK protocol
(`MACRO GET` / `MACRO SET n`).
