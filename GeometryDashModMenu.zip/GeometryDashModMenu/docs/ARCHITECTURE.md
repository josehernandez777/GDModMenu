# Architecture

Hybrid: Kotlin app + native C++ module, one APK.

```
app/src/main/java/com/example/gdmodmenu/
  MainActivity.kt        fullscreen shell, navigation rail, page transitions
  ui/                    view helpers (Ui.kt) and per-category pages (PageFactory.kt)
  features/              ModFeature contract, Category/Availability, FeatureRegistry (pure Kotlin)
  nativebridge/          NativeBridge: loads libgdmodmenu.so, JNI declarations
app/src/main/cpp/
  CMakeLists.txt         builds libgdmodmenu.so (C++17)
  native-lib.cpp         JNI entry points only
  core/                  plain C++ logic (no JNI), testable on its own
```
Rules: UI never talks to JNI directly; JNI functions only translate types and delegate to `core/`.
Packages `macros/`, `settings/`, `data/` are created in the milestones that need them (no empty placeholders).

## Feature contract
`ModFeature` = id, name, description, category, `checkAvailability()`. A feature is reported as
`AVAILABLE` only when it truly works; the UI disables switches otherwise.
Enable/configure hooks and persistence are added in Milestones 2 and 4.
