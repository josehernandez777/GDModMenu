# Build

## Versions
| Component | Version |
|---|---|
| Gradle | 8.7 |
| Android Gradle Plugin | 8.5.2 |
| Kotlin | 1.9.24 |
| JDK | 17 |
| compileSdk / targetSdk / minSdk | 34 / 34 / 26 |
| NDK | 26.1.10909125 |
| CMake | 3.22.1 |
| ABIs | arm64-v8a (primary), armeabi-v7a |

## GitHub Actions (recommended)
1. Create an empty GitHub repository.
2. Upload the contents of this folder to the repo root (keep `.github/workflows/android-build.yml`).
3. Open the **Actions** tab. The build runs on every push, or run it manually: *Android Build* -> *Run workflow*.
4. When it finishes, open the run and download the artifact **gd-mod-menu-debug-apk** (a zip containing `app-debug.apk`).
5. On the phone: unzip, enable "install unknown apps" for your file manager, install the APK.

The repo has no Gradle wrapper jar; the workflow installs Gradle 8.7 itself.

## Locally
Android Studio (Koala or newer) can open the folder directly, or with Gradle 8.7 installed:
`gradle testDebugUnitTest assembleDebug`. The APK is at `app/build/outputs/apk/debug/`.

## If the build fails
Open the failed step in the Actions log, and send the error text. Lint and test reports are uploaded as the
**build-reports** artifact.
