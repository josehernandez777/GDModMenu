# Injection into Geometry Dash (own copy, personal use)

1. CI builds `libgdmenu_payload.so` (arm64-v8a, armeabi-v7a).
2. `tools/patch_gd_apk.sh` adds it as a dependency of the game's `libcocos2dcpp.so` (patchelf) inside YOUR copy of
   the APK, re-signs it with a new key. No smali edits, no root, no hooking of system code.
3. At game start the payload waits for `libcocos2dcpp.so`, writes its exported symbols to
   `/sdcard/Android/data/<game package>/files/` (`gdmenu_symbols_gd.txt`, `gdmenu_symbols_all.txt`, `gdmenu.log`)
   and listens on 127.0.0.1:38999. The app's GAME LINK page talks to it.

Current state: probe only. No hooks yet. noclip/hitboxes/speed need the real symbols of version 2.2091, which is
what the symbol files provide. Not tested on a device yet.
Notes: use the full single APK (not xapk/split); uninstall the original first (signature differs); do not use online or
on leaderboards.
