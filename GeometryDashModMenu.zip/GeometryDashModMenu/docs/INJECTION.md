# Injection into Geometry Dash (own copy, personal, offline use)

## How the code gets into the game
1. CI builds `libgdmenu_payload.so` (arm64-v8a, armeabi-v7a).
2. `tools/patch_gd_apk.sh` adds it as a dependency of the game's `libcocos2dcpp.so` (patchelf) inside YOUR copy
   of the game (single APK or SAI `.apks` bundle) and re-signs it with a new key. No root, no smali edits.
3. When the game starts, the payload waits for `libcocos2dcpp.so`, reads its exported symbols and writes
   `gdmenu_symbols_gd.txt`, `gdmenu_symbols_all.txt` and `gdmenu.log` to `Android/data/<game package>/files/`.

## What is hooked (arm64 only)
Each function is found by its EXACT mangled name in the game's export table (`dlsym`). If the name is not
exported, nothing is hooked and STATUS lists similar exports. The inline hook engine (`hook.cpp`) refuses
functions whose first 16 bytes contain pc-relative instructions instead of guessing.

| Hooked function | Used for |
|---|---|
| `PlayLayer::update(float)` | game clock, macro playback timing |
| `GJBaseGameLayer::pushButton(int,bool)` / `releaseButton(int,bool)` | recording and injecting real inputs |
| `PlayLayer::destroyPlayer(PlayerObject*,GameObject*)` | noclip (player is never destroyed while ON) |
| `PlayLayer::resetLevel()` | resets the macro clock on every attempt |
| `cocos2d::CCScheduler::update(float)` | speedhack, freeze, frame step, FPS measurement |
| `GJBaseGameLayer::shakeCamera(float,float,float)` | No shake |
| `PlayerObject::playDeathEffect()` | No death effect |
| `CCDirector::drawScene()` + `Cocos2dxRenderer.nativeTouches*` | in-game ImGui menu and its touch input |

Macro timing is game time per rendered frame, not physics-step exact: very tight sections can desync.

## In-game menu
Dear ImGui (tag v1.90.9, fetched by CMake; if unreachable the payload builds without the menu) is drawn after each frame.
The menu only shows controls whose hook is installed. Touches that start inside the menu are consumed; others reach the game.
It has its own crash guard (`ui.lock`), separate from the hooks.

## Not implemented (needs the game's internal class layouts, which are not available)
Hitbox viewer, trajectory, start position, practice-mode changes, instant respawn, no flash, FPS cap.

## Crash guard
Hooks are installed at game start. If the game crashes twice in a row after hooks were installed (before surviving 600
in-level frames), the third launch starts in SAFE MODE with hooks off. `HOOKS ON` from GAME LINK retries.

## Control channel
Loopback TCP 127.0.0.1:38999, line protocol: `STATUS`, `HOOKS ON`, `NOCLIP ON|OFF`, `MACRO RECORD|STOP|GET|PLAY`,
`MACRO SET n` + n lines `timeMs,D|U,button,p2`, `SYMBOLS <filter>`.

## Status
Compiles in CI-equivalent syntax checks; the hook engine and all hooks have NOT been run on a device yet.
Use the full APK/APKS of your own copy; uninstall the original first (signature differs). Offline/local use only.
