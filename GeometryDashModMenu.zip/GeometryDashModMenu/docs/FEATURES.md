# Features

| ID | Category | Status | Notes |
|---|---|---|---|
| player.profiles | PLAYER | Planned (M2) | Own app only |
| player.controls | PLAYER | Planned (M2) | Own app only |
| visual.fps_counter | VISUAL | Blocked | Needs game process access |
| visual.hitbox_viewer | VISUAL | Blocked | Needs game process access |
| visual.indicators | VISUAL | Planned (M2) | Own test environment |
| gameplay.practice_music | GAMEPLAY | Blocked | Needs game process access |
| gameplay.speed | GAMEPLAY | Blocked | Needs game process access |
| gameplay.practice_options | GAMEPLAY | Planned (M2) | Preferences only |
| Macro bot | MACROS | Planned (M3) | Test environment first |
| Settings / profiles / import-export | CONFIGURATION | Planned (M2) | |

Nothing is marked Available in Milestone 1.
