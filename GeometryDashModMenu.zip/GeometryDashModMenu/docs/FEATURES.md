# Features

| ID | Category | Status | Notes |
|---|---|---|---|
| player.profiles | PLAYER | Works | Profiles in CONFIGURATION |
| player.controls | PLAYER | Works | Tap duration / playback speed (test pad) |
| visual.indicators | VISUAL | Works | Page animations, keep screen on |
| visual.fps_counter | VISUAL | Blocked | Needs game process access (payload probe first) |
| visual.hitbox_viewer | VISUAL | Blocked | Needs game symbols |
| gameplay.practice_music | GAMEPLAY | Blocked | Needs game symbols |
| gameplay.speed | GAMEPLAY | Blocked | Needs game symbols |
| gameplay.practice_options | GAMEPLAY | Planned | |
| Macro bot | MACROS | Works (test pad) | Record, save, load, rename, copy, delete, edit, play, pause, stop, restart. Not connected to the game |
| Settings | CONFIGURATION | Works | Persistent, profiles, reset, export/import via clipboard |
| Game link | GAME LINK | Works with patched game | Probe only (lists symbols) |

Blocked features need the symbols of the installed game version; see INJECTION.md.
