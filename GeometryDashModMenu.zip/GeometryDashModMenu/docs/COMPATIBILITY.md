# Compatibility and integration limits (Android 10, no root)

Target: Geometry Dash Android 2.2091, Galaxy Note 9 (Snapdragon), Android 10, ARM64.

## Key fact
Loading a JNI library inside this app does NOT let it change Geometry Dash. Android runs each app in its own
process and UID sandbox. This app cannot read or write the game's memory, hook its functions or load code into it.

## Mechanisms and what is realistic
| Mechanism | Needs | Verdict |
|---|---|---|
| Hook/inject into the game process (Frida, LSPosed, Zygisk, ptrace) | root or modified system | Out of scope (violates project rules) |
| Repackage the APK with an embedded library | modifying the game's files | Out of scope without explicit authorization from the rights holder; also changes the signature |
| Accessibility service (`dispatchGesture`) to send taps | user enables it manually in Settings | Technically possible for tap replay; needs user consent; to be evaluated in Milestone 5 |
| Overlay (`SYSTEM_ALERT_WINDOW`) | user grants permission | Possible for showing UI on top of the game, but it cannot read game state |
| Screen capture (`MediaProjection`) | user consent each session | Could estimate on-screen things, not hitboxes or internal values |
| Foreground app detection (`UsageStatsManager`) | special access granted by user | Possible, read-only |

## Consequences for the features
- FPS counter, hitbox viewer, practice music, speed: need in-process access -> blocked in this architecture.
  Alternatives: implement them in this app's own test environment (Milestone 2/3), or use the game's own options.
- Macro bot: record/edit/replay will work in our own test environment. Replaying into the real game would rely on
  the accessibility route above, with timing limited by Android input latency.
- Macros and bots are generally not accepted on official leaderboards or rated levels; use for personal practice.

These findings are from design analysis, not yet tested on a device. Milestone 5 will verify them.
